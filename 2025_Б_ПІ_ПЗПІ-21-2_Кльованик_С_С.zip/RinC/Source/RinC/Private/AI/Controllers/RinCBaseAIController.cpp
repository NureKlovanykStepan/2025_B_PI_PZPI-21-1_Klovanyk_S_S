// My copyright notice

#include "AI/Controllers/RinCBaseAIController.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackboardComponent.h"

ARinCBaseAIController::ARinCBaseAIController()
{
    BehaviorTreeComponent = CreateDefaultSubobject<UBehaviorTreeComponent>("BehaviorTreeComponent");
    BlackboardComponent = CreateDefaultSubobject<UBlackboardComponent>("BlackboardComponent");
}

void ARinCBaseAIController::RunBattleBehaviorTree()
{
    if (!IsValid(BehaviorTreeComponent)) return;

    BehaviorTreeComponent->StartLogic();
}

void ARinCBaseAIController::StopBattleBehaviorTree()
{
    if (!IsValid(BehaviorTreeComponent)) return;

    BehaviorTreeComponent->StopTree();
}
