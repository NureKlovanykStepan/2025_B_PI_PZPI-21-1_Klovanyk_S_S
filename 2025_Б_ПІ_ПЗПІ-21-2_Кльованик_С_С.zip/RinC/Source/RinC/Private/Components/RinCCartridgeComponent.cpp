// Fill out your copyright notice in the Description page of Project Settings.

#include "Components/RinCCartridgeComponent.h"
#include "Characters/RinCBaseCharacter.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "Controllers/RinCBasePlayerController.h"
#include "RinCPartyInventoryComponent.h"
#include "Kismet/GameplayStatics.h"

URinCCartridgeComponent::URinCCartridgeComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void URinCCartridgeComponent::BeginPlay()
{
	Super::BeginPlay();
}

void URinCCartridgeComponent::EquipCartridge(ARinCBaseCartridge* Cartridge)
{
    if (!Cartridge) return;

    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!OwnerCharacter) return;

    ARinCBasePlayerController* PlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(OwnerCharacter, 0));
    if (!PlayerController) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = PlayerController->GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    AddEquippedCartridge(Cartridge);

    PartyInventoryComponent->UseCartridge(Cartridge);
}

void URinCCartridgeComponent::UnequipCartridge(ARinCBaseCartridge* Cartridge)
{
    if (!Cartridge) return;

    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!OwnerCharacter) return;

    ARinCBasePlayerController* PlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(OwnerCharacter, 0));
    if (!PlayerController) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = PlayerController->GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    Cartridge->Unequip(OwnerCharacter->GetAbilitySystemComponent());

    EquippedCartridges.RemoveSingle(Cartridge);

    PartyInventoryComponent->StoreCartridge(Cartridge);
}

void URinCCartridgeComponent::AddEquippedCartridge(ARinCBaseCartridge* Cartridge)
{
    if (!IsValid(Cartridge)) return;

    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!OwnerCharacter) return;

    Cartridge->Equip(OwnerCharacter->GetAbilitySystemComponent());

    EquippedCartridges.Add(Cartridge);
}

void URinCCartridgeComponent::UnequipAllCartridges()
{
    TArray<ARinCBaseCartridge*> TempEquippedCartridges = EquippedCartridges;

    for (ARinCBaseCartridge* Cartridge : TempEquippedCartridges)
    {
        UnequipCartridge(Cartridge);
    }
}