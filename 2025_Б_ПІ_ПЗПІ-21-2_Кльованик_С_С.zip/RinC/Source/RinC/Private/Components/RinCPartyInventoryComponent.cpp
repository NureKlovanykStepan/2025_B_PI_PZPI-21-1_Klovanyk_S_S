// My copyright notice

#include "Components/RinCPartyInventoryComponent.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/GameModeBase.h"
#include "Controllers/RinCBasePlayerController.h"
#include "NiagaraFunctionLibrary.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "Miscellaneous/RinCResourceLoader.h"
#include "DataAssets/RinCCartridgeData.h"
#include "GameFramework/SpringArmComponent.h"
#include "RinCCartridgeComponent.h"

URinCPartyInventoryComponent::URinCPartyInventoryComponent()
    : HeroPartySize(3), CurrentHeroIndex(-1), HeroSwitchEffect(nullptr)
{
	PrimaryComponentTick.bCanEverTick = false;
}

void URinCPartyInventoryComponent::BeginPlay()
{
	Super::BeginPlay();

    FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(this, &ThisClass::StoreInitialCartridges, InitialCartridgesDataIds);
    RinCResourceLoader::LoadPrimaryAssets(InitialCartridgesDataIds, TArray<FName>(), Delegate);
}

void URinCPartyInventoryComponent::StoreCartridge(ARinCBaseCartridge* CartridgeToStore)
{
    if (!IsValid(CartridgeToStore)) return;

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCCartridgeData>(CartridgeToStore->GetDataPrimaryAssetId(),
        TArray<FName>(), this, &ThisClass::StoreCartridgeInternal, CartridgeToStore);
}

void URinCPartyInventoryComponent::StoreCartridges(TArray<ARinCBaseCartridge*> CartridgesToStore)
{
    if (CartridgesToStore.IsEmpty()) return;

    TArray<FPrimaryAssetId> CartridgeIds;
    for (ARinCBaseCartridge* Cartridge : CartridgesToStore)
    {
        if (!IsValid(Cartridge)) continue;

        CartridgeIds.Add(Cartridge->GetDataPrimaryAssetId());
    }

    FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(this, &ThisClass::StoreCartridgesInternal, CartridgesToStore);
    RinCResourceLoader::LoadPrimaryAssets(CartridgeIds, TArray<FName>(), Delegate);
}

void URinCPartyInventoryComponent::UseCartridge(ARinCBaseCartridge* CartridgeToUse)
{
    if (!IsValid(CartridgeToUse)) return;

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCCartridgeData>(CartridgeToUse->GetDataPrimaryAssetId(), 
        TArray<FName>(), this, &ThisClass::UseCartridgeInternal, CartridgeToUse);
}

void URinCPartyInventoryComponent::StoreCartridgeInternal(ARinCBaseCartridge* CartridgeToStore)
{
    if (!IsValid(CartridgeToStore)) return;

    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeToStore->GetDataPrimaryAssetId()));
    if (!IsValid(CartridgeData)) return;

    TArray<ARinCBaseCartridge*>& CartridgesByType = StoredCartridges.FindOrAdd(CartridgeData->CartridgeType);

    CartridgesByType.Add(CartridgeToStore);
}

void URinCPartyInventoryComponent::StoreCartridgesInternal(TArray<ARinCBaseCartridge*> CartridgesToStore)
{
    for (ARinCBaseCartridge* Cartridge : CartridgesToStore)
    {
        StoreCartridgeInternal(Cartridge);
    }
}

void URinCPartyInventoryComponent::UseCartridgeInternal(ARinCBaseCartridge* CartridgeToUse)
{
    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeToUse->GetDataPrimaryAssetId()));
    if (!IsValid(CartridgeData)) return;

    TArray<ARinCBaseCartridge*>& CartridgesByType = StoredCartridges.FindOrAdd(CartridgeData->CartridgeType);
    CartridgesByType.RemoveSingle(CartridgeToUse);
}

void URinCPartyInventoryComponent::StoreInitialCartridges(TArray<FPrimaryAssetId> InitialIds)
{
    for (const FPrimaryAssetId& InitialId : InitialIds)
    {
        StoreInitialCartridgeInternal(InitialId);
    }
}

void URinCPartyInventoryComponent::StoreInitialCartridgeInternal(FPrimaryAssetId LoadedCartridgeDataId)
{
    AActor* Owner = GetOwner();
    if (!IsValid(Owner)) return;

    UWorld* World = Owner->GetWorld();
    if (!IsValid(World)) return;

    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(LoadedCartridgeDataId));
    if (!IsValid(CartridgeData)) return;

    TArray<ARinCBaseCartridge*>& CartridgesByType = StoredCartridges.FindOrAdd(CartridgeData->CartridgeType);

    /* Spawn a new cartridge instance and assign it with data */
    ARinCBaseCartridge* CartridgeToStore = World->SpawnActorDeferred<ARinCBaseCartridge>(ARinCBaseCartridge::StaticClass(), FTransform());
    CartridgeToStore->SetCartridgeDataPrimaryAssetId(LoadedCartridgeDataId);
    CartridgeToStore->FinishSpawning(FTransform());

    CartridgeData->InitCartridgeStats(CartridgeToStore);

    CartridgesByType.Add(CartridgeToStore);
}

FRinCStoredCartridges URinCPartyInventoryComponent::GetAllStoredCartridges()
{
    FRinCStoredCartridges AllStoredCartridges;
    AllStoredCartridges.StoredCartridges = StoredCartridges;

    return AllStoredCartridges;
}

TArray<ARinCBaseCartridge*> URinCPartyInventoryComponent::GetStoredCartridgesByType(ERinCCartridgeType Type)
{
    return StoredCartridges.FindOrAdd(Type);
}

void URinCPartyInventoryComponent::UnequipAllHeroCartridges(ARinCBaseHeroCharacter* Hero)
{
    if (!IsValid(Hero)) return;

    URinCCartridgeComponent* CartridgeComponent = Hero->GetCartridgeComponent();
    if (!IsValid(CartridgeComponent)) return;

    CartridgeComponent->UnequipAllCartridges();
}

ARinCBaseHeroCharacter* URinCPartyInventoryComponent::SpawnHeroFromClass(TSubclassOf<ARinCBaseHeroCharacter> HeroClass)
{
    if (!IsValid(HeroClass)) return nullptr;

    UWorld* World = GetWorld();
    if (!IsValid(World)) return nullptr;

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    ARinCBaseHeroCharacter* SpawnedHero = World->SpawnActor<ARinCBaseHeroCharacter>(
        HeroClass,
        FVector::ZeroVector,
        FRotator::ZeroRotator,
        SpawnParams
    );

    HideHero(SpawnedHero);

    return SpawnedHero;
}

void URinCPartyInventoryComponent::HideHero(ARinCBaseHeroCharacter* Hero)
{
    if (!IsValid(Hero)) return ;

    Hero->SetActorHiddenInGame(true);
    Hero->SetActorEnableCollision(false);
}

void URinCPartyInventoryComponent::ShowHero(ARinCBaseHeroCharacter* Hero)
{
    if (!IsValid(Hero)) return;

    Hero->SetActorHiddenInGame(false);
    Hero->SetActorEnableCollision(true);
}

ARinCBaseHeroCharacter* URinCPartyInventoryComponent::ReplacePartyHero(ARinCBaseHeroCharacter* HeroToReplace)
{
    if (!IsValid(HeroToReplace) || !IsValid(UnusedHeroClasses.Top())) return nullptr;

    UClass* HeroClassToUse = UnusedHeroClasses.Pop();
    UnusedHeroClasses.Insert(HeroToReplace->GetClass(), 0);

    UnequipAllHeroCartridges(HeroToReplace);

    int32 HeroToReplaceId = CurrentPartyHeroes.Find(HeroToReplace);
    if (!CurrentPartyHeroes.IsValidIndex(HeroToReplaceId)) return nullptr;

    ARinCBaseHeroCharacter* SpawnedHero = SpawnHeroFromClass(HeroClassToUse);
    if (!IsValid(SpawnedHero)) return nullptr;

    CurrentPartyHeroes[HeroToReplaceId] = SpawnedHero;

    /* Handle the case where the Hero we are trying to replace was active */
    if (HeroToReplaceId == CurrentHeroIndex)
    {
        SetActiveHero(CurrentHeroIndex, HeroToReplace);
    }

    HeroToReplace->Destroy();

    return SpawnedHero;
}

void URinCPartyInventoryComponent::InitUnusedHeroClasses()
{
    UnusedHeroClasses = AllAvaliableHeroClasses;

    for (UClass* HeroClass : StartingHeroClasses)
    {
        int32 NumRemoved = UnusedHeroClasses.RemoveSingle(HeroClass);

        checkf(NumRemoved != 0, TEXT("A Hero class from StartingHeroClasses should be listed in AllAvaliableHeroClasses"))
    }
}

void URinCPartyInventoryComponent::InitializeHeroParty()
{
    checkf(HeroPartySize == StartingHeroClasses.Num(), TEXT("HeroPartySize should be equal to StartingHeroClasses amount!"))

    InitUnusedHeroClasses();

    UWorld* World = GetWorld();
    if (!IsValid(World)) return;

    ARinCBasePlayerController* OwnerController = GetOwner<ARinCBasePlayerController>();
    if (!IsValid(OwnerController)) return;

    for (int32 i = 0; i < HeroPartySize; ++i)
    {
        ARinCBaseHeroCharacter* SpawnedHero = SpawnHeroFromClass(StartingHeroClasses[i]);
        if (IsValid(SpawnedHero)) CurrentPartyHeroes.Add(SpawnedHero);
    }

    if (CurrentPartyHeroes.Num() > 0) SetActiveHero(0);

    OwnerController->SetupInputComponent();
}

void URinCPartyInventoryComponent::SetActiveHero(int32 NewHeroIndex, ARinCBaseHeroCharacter* PrevHero)
{
    if (!CurrentPartyHeroes.IsValidIndex(NewHeroIndex)) return;

    ARinCBasePlayerController* OwnerController = GetOwner<ARinCBasePlayerController>();
    if (!IsValid(OwnerController)) return;

    ARinCBaseHeroCharacter* NewHero = CurrentPartyHeroes[NewHeroIndex];
    if (!IsValid(NewHero)) return;

    FVector CharacterLocationToUse;
    FRotator CharacterRotationToUse;

    FRotator SavedControlRotation = OwnerController->GetControlRotation();

    if (CurrentHeroIndex != -1)
    {
        if (IsValid(PrevHero))
        {
            CharacterLocationToUse = PrevHero->GetActorLocation();
            CharacterRotationToUse = PrevHero->GetActorRotation();
        }
        else
        {
            ARinCBaseHeroCharacter* CurrentHero = CurrentPartyHeroes[CurrentHeroIndex];
            if (!IsValid(CurrentHero)) return;

            CharacterLocationToUse = CurrentHero->GetActorLocation();
            CharacterRotationToUse = CurrentHero->GetActorRotation();
        }
    }
    else
    {
        /* If it's first hero we are trying to posses, use PlayerStart's transform */
        AGameModeBase* GameMode = UGameplayStatics::GetGameMode(OwnerController);
        if (!IsValid(GameMode)) return;

        AActor* ChosenPlayerStart = GameMode->ChoosePlayerStart(OwnerController);
        if (!IsValid(ChosenPlayerStart)) return;

        CharacterLocationToUse = ChosenPlayerStart->GetActorLocation();
        CharacterRotationToUse = ChosenPlayerStart->GetActorRotation();
    }

    NewHero->SetActorLocation(CharacterLocationToUse);
    NewHero->SetActorRotation(CharacterRotationToUse);
    ShowHero(NewHero);

    OwnerController->Possess(NewHero);

    OwnerController->SetControlRotation(SavedControlRotation);

    if (IsValid(HeroSwitchEffect))
    {
        UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), HeroSwitchEffect, NewHero->GetActorLocation(), FRotator::ZeroRotator);
    }

    CurrentHeroIndex = NewHeroIndex;
}

void URinCPartyInventoryComponent::SwitchToNextHero()
{
    if (CurrentPartyHeroes.Num() == 0) return;

    ARinCBasePlayerController* OwnerController = GetOwner<ARinCBasePlayerController>();
    if (!IsValid(OwnerController)) return;

    ARinCBaseHeroCharacter* CurrentHero = CurrentPartyHeroes[CurrentHeroIndex];
    if (!IsValid(CurrentHero)) return;

    OwnerController->UnPossess();
    HideHero(CurrentHero);

    int32 NewHeroIndex = CurrentHeroIndex < CurrentPartyHeroes.Num() - 1 ? CurrentHeroIndex + 1 : 0;

    SetActiveHero(NewHeroIndex);
}

void URinCPartyInventoryComponent::HidePartyHeroes()
{
    for (ARinCBaseHeroCharacter* Hero : CurrentPartyHeroes)
    {
        HideHero(Hero);
    }
}

