// Fill out your copyright notice in the Description page of Project Settings.

#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"
#include "GameplayEffectExtension.h"
#include "Characters/RinCBaseCharacter.h"
#include "RinCCombatComponent.h"
#include "AbilitySystemComponent.h"
#include "GASClasses/Abilities/RinCGASHelperLibrary.h"

void URinCBaseAttributeSet::PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue)
{
    Super::PreAttributeChange(Attribute, NewValue);

    const float MaxPercent = 100.0f;

    if (Attribute == GetHealthAttribute())
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, GetHealthMax());
    }
    else if (Attribute == GetDamageAttribute()) 
    {
        NewValue = FMath::Max(NewValue, 0.0f);
    }
    else if (Attribute == GetEnergyAttribute()) 
    {
        NewValue = FMath::Max(NewValue, 0.0f);
    }
    else if (Attribute == GetMoraleAttribute()) 
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, GetMoraleMax());
    }
    else if (Attribute == GetMoraleThresholdAttribute()) 
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, GetMoraleMax());
    }
    else if (Attribute == GetAttackAttribute()) 
    {
        NewValue = FMath::Max(NewValue, 0.0f);
    }
    else if (Attribute == GetDefenseAttribute()) 
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, MaxPercent);
    }
    else if (Attribute == GetCritChanceAttribute()) 
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, MaxPercent);
    }
    else if (Attribute == GetDodgeChanceAttribute()) 
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, MaxPercent);
    }
    else if (Attribute == GetActionPointsAttribute())
    {
        NewValue = FMath::Clamp(NewValue, 0.0f, GetActionPointsMax());
    }
}

void URinCBaseAttributeSet::PostAttributeChange(const FGameplayAttribute& Attribute, float OldValue, float NewValue)
{
    Super::PostAttributeChange(Attribute, OldValue, NewValue);

    UAbilitySystemComponent* const ASC = GetOwningAbilitySystemComponentChecked();
    if (!ASC) return;

    if (Attribute == GetHealthMaxAttribute())
    {
        /* Update Health when HealthMax was changed (by some cartridges) */
        ASC->ApplyModToAttribute(GetHealthAttribute(), EGameplayModOp::Override, NewValue);
    }
    else if (Attribute == GetEnergyBaseAttribute())
    {
        ASC->ApplyModToAttribute(GetEnergyAttribute(), EGameplayModOp::Override, NewValue);
    }
}

void URinCBaseAttributeSet::PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data)
{
    Super::PostGameplayEffectExecute(Data);

    /* Get the Target actor, which should be our owner */
    AActor* TargetActor = nullptr;
    AController* TargetController = nullptr;
    ARinCBaseCharacter* TargetCharacter = nullptr;
    if (Data.Target.AbilityActorInfo.IsValid() && Data.Target.AbilityActorInfo->AvatarActor.IsValid())
    {
        TargetActor = Data.Target.AbilityActorInfo->AvatarActor.Get();
        TargetController = Data.Target.AbilityActorInfo->PlayerController.Get();
        TargetCharacter = Cast<ARinCBaseCharacter>(TargetActor);
    }

    if (Data.EvaluatedData.Attribute == GetDamageAttribute())
    {
        const float DamageDone = GetDamage();
        SetDamage(0.0f);

        if (DamageDone < 0.0f || !IsValid(TargetCharacter)) return;

        URinCCombatComponent* TargetCombatComponent = TargetCharacter->GetCombatComponent();
        if (!IsValid(TargetCombatComponent)) return;

        FString FloatingString;

        bool WasDodged = URinCGASHelperLibrary::GetWasDodged(Data.EffectSpec.GetContext());
        if (WasDodged)
        {
            FloatingString.Append("<Battle>Dodged!</>");
            TargetCombatComponent->SpawnFloatingTextActor(FloatingString, TargetCharacter->GetActorTransform());
            return;
        }

        bool IsCrit = URinCGASHelperLibrary::GetIsCrit(Data.EffectSpec.GetContext());
        if (IsCrit)
        {
            FloatingString.Append("<Battle>Crit!</>\n");
        }

        const float NewHealth = GetHealth() - DamageDone;
        SetHealth(FMath::Clamp(NewHealth, 0.0f, GetHealthMax()));

        FloatingString.Append("<Battle>" + FString::FormatAsNumber(DamageDone) + "</>");
        TargetCombatComponent->SpawnFloatingTextActor(FloatingString, TargetCharacter->GetActorTransform());
    }

    ClampAttributeBaseValues(Data);
}

void URinCBaseAttributeSet::ClampAttributeBaseValues(const FGameplayEffectModCallbackData& Data)
{
    const float MaxPercent = 100.0f;
    
    if (Data.EvaluatedData.Attribute == GetEnergyAttribute())
    {
        SetEnergy(FMath::Max(GetEnergy(), 0.0f));
    }
    else if (Data.EvaluatedData.Attribute == GetMoraleAttribute())
    {
        SetMorale(FMath::Clamp(GetMorale(), 0.0f, GetMoraleMax()));
    }
    else if (Data.EvaluatedData.Attribute == GetMoraleThresholdAttribute())
    {
        SetMoraleThreshold(FMath::Clamp(GetMoraleThreshold(), 0.0f, GetMoraleMax()));
    }
    else if (Data.EvaluatedData.Attribute == GetAttackAttribute())
    {
        SetAttack(FMath::Max(GetAttack(), 0.0f));
    }
    else if (Data.EvaluatedData.Attribute == GetDefenseAttribute())
    {
        SetDefense(FMath::Clamp(GetDefense(), 0.0f, MaxPercent));
    }
    else if (Data.EvaluatedData.Attribute == GetCritChanceAttribute())
    {
        SetCritChance(FMath::Clamp(GetCritChance(), 0.0f, MaxPercent));
    }
    else if (Data.EvaluatedData.Attribute == GetDodgeChanceAttribute())
    {
        SetDodgeChance(FMath::Clamp(GetDodgeChance(), 0.0f, MaxPercent));
    }
    else if (Data.EvaluatedData.Attribute == GetActionPointsAttribute())
    {
        SetActionPoints(FMath::Clamp(GetActionPoints(), 0.0f, GetActionPointsMax()));
    }
}
