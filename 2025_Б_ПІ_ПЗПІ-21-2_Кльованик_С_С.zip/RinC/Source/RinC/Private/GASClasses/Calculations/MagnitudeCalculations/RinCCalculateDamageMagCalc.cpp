// Fill out your copyright notice in the Description page of Project Settings.

#include "GASClasses/Calculations/MagnitudeCalculations/RinCCalculateDamageMagCalc.h"
#include "AttributeSets/RinCBaseAttributeSet.h"
#include "GASClasses/Abilities/RinCGASHelperLibrary.h"
#include "DataAssets/RinCElementalScalarData.h"

URinCCalculateDamageMagCalc::URinCCalculateDamageMagCalc()
{
    /* Capture Source attributes */
    SourceAttackDef.AttributeToCapture = URinCBaseAttributeSet::GetAttackAttribute();
    SourceAttackDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Source;
    SourceAttackDef.bSnapshot = false;

    SourceCritChanceDef.AttributeToCapture = URinCBaseAttributeSet::GetCritChanceAttribute();
    SourceCritChanceDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Source;
    SourceCritChanceDef.bSnapshot = false;

    SourceMoraleDef.AttributeToCapture = URinCBaseAttributeSet::GetMoraleAttribute();
    SourceMoraleDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Source;
    SourceMoraleDef.bSnapshot = false;

    SourceMoraleThresholdDef.AttributeToCapture = URinCBaseAttributeSet::GetMoraleThresholdAttribute();
    SourceMoraleThresholdDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Source;
    SourceMoraleThresholdDef.bSnapshot = false;

    /* Capture target attributes */
    TargetDefenseDef.AttributeToCapture = URinCBaseAttributeSet::GetDefenseAttribute();
    TargetDefenseDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Target;
    TargetDefenseDef.bSnapshot = false;

    TargetDodgeChanceDef.AttributeToCapture = URinCBaseAttributeSet::GetDodgeChanceAttribute();
    TargetDodgeChanceDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Target;
    TargetDodgeChanceDef.bSnapshot = false;

    TargetMoraleDef.AttributeToCapture = URinCBaseAttributeSet::GetMoraleAttribute();
    TargetMoraleDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Target;
    TargetMoraleDef.bSnapshot = false;

    TargetMoraleThresholdDef.AttributeToCapture = URinCBaseAttributeSet::GetMoraleThresholdAttribute();
    TargetMoraleThresholdDef.AttributeSource = EGameplayEffectAttributeCaptureSource::Target;
    TargetMoraleThresholdDef.bSnapshot = false;

    RelevantAttributesToCapture.Add(SourceAttackDef);
    RelevantAttributesToCapture.Add(SourceCritChanceDef);
    RelevantAttributesToCapture.Add(SourceMoraleDef);
    RelevantAttributesToCapture.Add(SourceMoraleThresholdDef);

    RelevantAttributesToCapture.Add(TargetDefenseDef);
    RelevantAttributesToCapture.Add(TargetDodgeChanceDef);
    RelevantAttributesToCapture.Add(TargetMoraleDef);
    RelevantAttributesToCapture.Add(TargetMoraleThresholdDef);
}

float URinCCalculateDamageMagCalc::CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const
{
    const FGameplayTagContainer* SourceTags = Spec.CapturedSourceTags.GetAggregatedTags();
    const FGameplayTagContainer* TargetTags = Spec.CapturedTargetTags.GetAggregatedTags();

    FAggregatorEvaluateParameters EvaluationParams;
    EvaluationParams.SourceTags = SourceTags;
    EvaluationParams.TargetTags = TargetTags;

    /* Get required attribute values */
    float SourceAttack = 0.0f;
    GetCapturedAttributeMagnitude(SourceAttackDef, Spec, EvaluationParams, SourceAttack);

    float SourceCritChance = 0.0f;
    GetCapturedAttributeMagnitude(SourceCritChanceDef, Spec, EvaluationParams, SourceCritChance);

    float SourceMorale = 0.0f;
    GetCapturedAttributeMagnitude(SourceMoraleDef, Spec, EvaluationParams, SourceMorale);

    float SourceMoraleThreshold = 0.0f;
    GetCapturedAttributeMagnitude(SourceMoraleThresholdDef, Spec, EvaluationParams, SourceMoraleThreshold);

    float TargetDefense = 0.0f;
    GetCapturedAttributeMagnitude(TargetDefenseDef, Spec, EvaluationParams, TargetDefense);

    float TargetDodgeChance = 0.0f;
    GetCapturedAttributeMagnitude(TargetDodgeChanceDef, Spec, EvaluationParams, TargetDodgeChance);

    float TargetMorale = 0.0f;
    GetCapturedAttributeMagnitude(TargetMoraleDef, Spec, EvaluationParams, TargetMorale);

    float TargetMoraleThreshold = 0.0f;
    GetCapturedAttributeMagnitude(TargetMoraleThresholdDef, Spec, EvaluationParams, TargetMoraleThreshold);

    const float MaxPercent = 100.0f;
    const float BaseMultiplier = 1.0f;

    /* Retrieve ability base damage scalar for Source attack */
    const float DamageBaseScalar = GetDamageBaseScalar(Spec);

    /* Determine the elemental scalar for the ability damage to a target */
    const float DamageElementalScalar = GetDamageElementalScalar(Spec, *TargetTags);

    const float AbilityDamage = SourceAttack * DamageBaseScalar * DamageElementalScalar;

    /* Check if the attack is dodged */ 
    float RandomChance = FMath::FRand() * MaxPercent;
    if (RandomChance < TargetDodgeChance)
    {
        URinCGASHelperLibrary::SetWasDodged(Spec.GetContext(), true);
        return 0.0f;
    }

    /* Calculate self morale-based damage reduction */ 
    float MoraleDamageReduction = (SourceMorale < SourceMoraleThreshold) ? 0.5f : BaseMultiplier;

    /* Calculate target morale-based damage multiplier */
    float MoraleDamageMultiplier = (TargetMorale < TargetMoraleThreshold) ? BaseMultiplier : BaseMultiplier;

    /* Calculate the defense reduction */
    float DefenseDamageReduction = 1.0f - (TargetDefense / MaxPercent);
    DefenseDamageReduction = FMath::Clamp(DefenseDamageReduction, 0.0f, 1.0f);

    /* Calculate critical hit multiplier */
    bool bIsCriticalHit = (FMath::FRand() * MaxPercent) < SourceCritChance;
    if (bIsCriticalHit) URinCGASHelperLibrary::SetIsCrit(Spec.GetContext(), true);
    float CritMultiplier = bIsCriticalHit ? 1.5f : BaseMultiplier;

    /* Calculate final damage */
    float FinalDamage = AbilityDamage * CritMultiplier * DefenseDamageReduction * MoraleDamageReduction * MoraleDamageMultiplier;

    return FinalDamage;
}

FGameplayTag URinCCalculateDamageMagCalc::GetTargetElementType(const FGameplayTagContainer& InTags) const
{
    const FGameplayTag ElementParentTag = FGameplayTag::RequestGameplayTag(FName("ElementType"), /*ErrorIfNotFound=*/true);

    return URinCGASHelperLibrary::GetElementTagFromContainer(InTags, ElementParentTag);
}

float URinCCalculateDamageMagCalc::GetDamageBaseScalar(const FGameplayEffectSpec& Spec) const
{
    const float MaxPercent = 100.0f;

    const FGameplayTag DamagePercentScalarTag = FGameplayTag::RequestGameplayTag(FName("Damage.Scalar"), /*ErrorIfNotFound=*/true);
    const float DamagePercentScalarValue = Spec.GetSetByCallerMagnitude(DamagePercentScalarTag, /*WarnIfNotFound=*/true, /*DefaultIfNotFound=*/0.0f);

    return DamagePercentScalarValue / MaxPercent;
}

float URinCCalculateDamageMagCalc::GetDamageElementalScalar(const FGameplayEffectSpec& Spec, const FGameplayTagContainer& InTags) const
{
    const float MaxPercent = 100.0f;

    const FGameplayTag AttackElementTypeTag = URinCGASHelperLibrary::GetElementTypeTag(Spec.GetContext());
    const FGameplayTag TargetElementTypeTag = GetTargetElementType(InTags);
    const float ElementalPercentScalarValue = ElementalScalarData->GetScalarValue(AttackElementTypeTag, TargetElementTypeTag);

    return ElementalPercentScalarValue / MaxPercent;
}
