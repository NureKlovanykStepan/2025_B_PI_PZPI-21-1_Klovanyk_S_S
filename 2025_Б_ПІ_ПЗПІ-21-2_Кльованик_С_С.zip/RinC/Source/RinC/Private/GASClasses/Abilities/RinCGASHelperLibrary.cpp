// My copyright notice

#include "GASClasses/Abilities/RinCGASHelperLibrary.h"

void URinCGASHelperLibrary::SetElementTypeTag(FGameplayEffectContextHandle ContextHandle, FGameplayTag Tag)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        RinCGameplayEffectContext->SetElementTypeTag(Tag);
    }
}

FGameplayTag URinCGASHelperLibrary::GetElementTypeTag(FGameplayEffectContextHandle ContextHandle)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        return RinCGameplayEffectContext->GetElementTypeTag();
    }
    return FGameplayTag();
}

void URinCGASHelperLibrary::SetIsCrit(FGameplayEffectContextHandle ContextHandle, bool IsCrit)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        RinCGameplayEffectContext->SetIsCrit(IsCrit);
    }
}

bool URinCGASHelperLibrary::GetIsCrit(FGameplayEffectContextHandle ContextHandle)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        return RinCGameplayEffectContext->GetIsCrit();
    }
    return false;
}

void URinCGASHelperLibrary::SetWasDodged(FGameplayEffectContextHandle ContextHandle, bool WasDodged)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        RinCGameplayEffectContext->SetWasDodged(WasDodged);
    }
}

bool URinCGASHelperLibrary::GetWasDodged(FGameplayEffectContextHandle ContextHandle)
{
    FRinCGameplayEffectContext* RinCGameplayEffectContext = static_cast<FRinCGameplayEffectContext*>(ContextHandle.Get());
    if (RinCGameplayEffectContext)
    {
        return RinCGameplayEffectContext->GetWasDodged();
    }
    return false;
}

FGameplayTag URinCGASHelperLibrary::GetElementTagFromContainer(const FGameplayTagContainer& InTags, const FGameplayTag& ParentTag)
{
    if (!ParentTag.IsValid())  return FGameplayTag::EmptyTag;

    for (const FGameplayTag& Tag : InTags)
    {
        if (Tag.MatchesTag(ParentTag) && Tag != ParentTag)
        {
            return Tag;
        }
    }

    return FGameplayTag::EmptyTag;
}

FGameplayTag URinCGASHelperLibrary::GetElementTagFromContainer(const TArray<FName>& InTagNames, const FGameplayTag& ParentTag)
{
    if (!ParentTag.IsValid()) return FGameplayTag::EmptyTag;

    for (const FName& TagName : InTagNames)
    {
        const FGameplayTag CurrentTag = FGameplayTag::RequestGameplayTag(TagName);
        if (!CurrentTag.IsValid()) continue;

        if (CurrentTag.MatchesTag(ParentTag) && CurrentTag != ParentTag)
        {
            return CurrentTag;
        }
    }

    return FGameplayTag::EmptyTag;
}