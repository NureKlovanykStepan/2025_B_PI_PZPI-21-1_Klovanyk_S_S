// Fill out your copyright notice in the Description page of Project Settings.

#include "GASClasses/Helpers/RinCBaseAbilitySet.h"
#include "AbilitySystemComponent.h"
#include "GameplayAbilitySpecHandle.h"
#include "DataAssets/RinCAbilityData.h"

TArray<FGameplayAbilitySpecHandle> URinCBaseAbilitySet::GrantAbilitiesToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent) const
{
    if (!AbilitySystemComponent) return TArray<FGameplayAbilitySpecHandle>();

    TArray<FGameplayAbilitySpecHandle> Handles;
    Handles.Reserve(AbilitySetItems.Num());

    for (const FRinCAbilityToGrant& AbilitySetItem : AbilitySetItems)
    {
        if (!IsValid(AbilitySetItem.GameplayAbilityData)) continue;

        Handles.AddUnique(AbilitySystemComponent->GiveAbility(
            FGameplayAbilitySpec(AbilitySetItem.GameplayAbilityData->GameplayAbility, 0, static_cast<uint32>(AbilitySetItem.InputKey))));
    }

    return Handles;
}
