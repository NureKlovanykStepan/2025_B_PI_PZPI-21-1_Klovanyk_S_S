// My copyright notice

#include "DataAssets/RinCElementalScalarData.h"

float URinCElementalScalarData::GetScalarValue(const FGameplayTag& AttackElementTag, const FGameplayTag& TargetElementTag)
{
    FRinCTargetElementScalar TargetElementResistance = GeneralElementalScalarMap.FindRef(AttackElementTag);

    return TargetElementResistance.TargetElementScalarMap.FindRef(TargetElementTag);
}
