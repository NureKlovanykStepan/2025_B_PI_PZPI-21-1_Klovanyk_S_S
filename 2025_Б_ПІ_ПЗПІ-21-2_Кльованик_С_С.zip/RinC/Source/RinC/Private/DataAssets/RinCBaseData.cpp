// My copyright notice

#include "DataAssets/RinCBaseData.h"

FPrimaryAssetId URinCBaseData::GetPrimaryAssetId() const
{
    return FPrimaryAssetId("Base", GetFName());
}
