// My copyright notice

#include "DataAssets/RinCCartridgeData.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "DataAssets/RinCAbilityData.h"
#include "GASClasses/Helpers/RinCBaseAbilitySet.h"
#include "AbilitySystemComponent.h"
#include "GameplayAbilitySpecHandle.h"

FPrimaryAssetId URinCCartridgeData::GetPrimaryAssetId() const
{
    return FPrimaryAssetId("Cartridge", GetFName());
}

FGameplayAbilitySpecHandle URinCCartridgeData::GrantAbilityToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent) const
{
    if (!AbilitySystemComponent || !GameplayAbilityDataToGrant) return FGameplayAbilitySpecHandle();

    ERinCAbilityInput AbilityInputKey = ERinCAbilityInput::None;

    switch (CartridgeType)
    {
    case ERinCCartridgeType::Weapon:
        AbilityInputKey = ERinCAbilityInput::WeaponAbility;
        break;

    case ERinCCartridgeType::Armor:
        AbilityInputKey = ERinCAbilityInput::ArmorAbility;
        break;

    default:
        break;
    }

    return AbilitySystemComponent->GiveAbility(
        FGameplayAbilitySpec(GameplayAbilityDataToGrant->GameplayAbility, 0, static_cast<uint32>(AbilityInputKey)));
}

void URinCCartridgeData::InitCartridgeStats(ARinCBaseCartridge* Cartridge) const
{
    if (!IsValid(Cartridge)) return;

    for (const FRinCCartridgeStat& Stat : CartridgeStats)
    {
        float CalculatedMagnitude = GenerateRandomStatMagnitude(Stat.MinMagnitude, Stat.MaxMagnitude, Stat.ProbabilityDistributionCurve);
        
        FRinCAppliedCartridgeStat AppliedStat;
        AppliedStat.Magnitude = CalculatedMagnitude;
        AppliedStat.StatTag = Stat.StatTag;

        Cartridge->AddAppliedStat(AppliedStat);
    }
}

float URinCCartridgeData::GenerateRandomStatMagnitude(float MinMagnitude, float MaxMagnitude, UCurveFloat* ProbabilityDistributionCurve) const
{
    float RandomInput = FMath::FRand();
    float BiasedOutput;

    if (IsValid(ProbabilityDistributionCurve))
    {
        /* Get Y value from curve based on random X input */
        BiasedOutput = ProbabilityDistributionCurve->GetFloatValue(RandomInput);

        BiasedOutput = FMath::Clamp(BiasedOutput, 0.0f, 1.0f);
    }
    else
    {
        BiasedOutput = RandomInput;
    }

    return FMath::Floor(FMath::Lerp(MinMagnitude, MaxMagnitude, BiasedOutput));
}