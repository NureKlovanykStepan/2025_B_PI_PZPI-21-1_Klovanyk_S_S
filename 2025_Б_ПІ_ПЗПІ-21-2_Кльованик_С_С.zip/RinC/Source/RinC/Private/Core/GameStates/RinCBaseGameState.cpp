// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/GameStates/RinCBaseGameState.h"
#include "Characters/RinCBaseCharacter.h"
#include "RinCCombatComponent.h"
#include "RinCBaseBattleArena.h"
#include "Kismet/GameplayStatics.h"
#include "GameModes/RinCBaseGameMode.h"
#include "RinCCartridgeComponent.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "Controllers/RinCBasePlayerController.h"
#include "AbilitySystemComponent.h"
#include "GameplayEffect.h"

ARinCBaseGameState::ARinCBaseGameState()
{

}

void ARinCBaseGameState::BeginPlay()
{
    Super::BeginPlay();

    checkf(IsValid(ResetRoundStatsGameplayEffect), TEXT("ResetRoundStatsGameplayEffect should be set!"))
    checkf(IsValid(ResetStatsAfterBattleGameplayEffect), TEXT("ResetStatsAfterBattleGameplayEffect should be set!"))
    checkf(!SoftBattleTransitionWidget.IsNull(), TEXT("SoftBattleTransitionWidget should be set!"))

    OnBattleStarted.AddUObject(this, &ThisClass::StartNewRound);

    OnRoundEnded.AddUObject(this, &ThisClass::StartNewRound);
}

void ARinCBaseGameState::StartNewRound()
{
    if (CheckDeadCharacters()) return;

    CurrentQueueTurnOrder.Empty();
    CurrentQueueTurnOrder.Append(CurrentAliveHeroCharacters);
    CurrentQueueTurnOrder.Append(CurrentAliveMonsterCharacters);

    /* Sort queue by speed on each round */
    ARinCBaseGameMode* BaseGameMode = Cast<ARinCBaseGameMode>(UGameplayStatics::GetGameMode(this));
    if (!IsValid(BaseGameMode)) return;

    BaseGameMode->SortBattleCharactersBySpeedAttribute(CurrentQueueTurnOrder);

    ExecuteQueueTurn();
}

void ARinCBaseGameState::ExecuteQueueTurn()
{
    if (CurrentQueueTurnOrder.IsEmpty())
    {
        OnRoundEnded.Broadcast();
        return;
    }

    ARinCBaseCharacter* TurnCharacter = CurrentQueueTurnOrder.Pop();
    if (!IsValid(TurnCharacter)) return;

    OnTurnStart.Broadcast(TurnCharacter);
}

void ARinCBaseGameState::ResetRoundStats(TWeakObjectPtr<UAbilitySystemComponent> WeakASC)
{
    if (!WeakASC.IsValid() || !IsValid(ResetRoundStatsGameplayEffect)) return;

    ApplyBattleGameplayEffect(WeakASC.Get(), ResetRoundStatsGameplayEffect);
}

void ARinCBaseGameState::ResetStatsAfterBattle(TWeakObjectPtr<UAbilitySystemComponent> WeakASC)
{
    if (!WeakASC.IsValid() || !IsValid(ResetStatsAfterBattleGameplayEffect)) return;

    ApplyBattleGameplayEffect(WeakASC.Get(), ResetStatsAfterBattleGameplayEffect);
}

void ARinCBaseGameState::ApplyBattleGameplayEffect(UAbilitySystemComponent* ASC, TSubclassOf<UGameplayEffect> GameplayEffect)
{
    if (!IsValid(ASC)) return;

    FGameplayEffectContextHandle ContextHandle = ASC->MakeEffectContext();
    ContextHandle.AddInstigator(ASC->GetAvatarActor(), ASC->GetAvatarActor());

    FGameplayEffectSpecHandle SpecHandle = ASC->MakeOutgoingSpec(GameplayEffect, 1.0f, ContextHandle);
    if (!SpecHandle.IsValid()) return;

    ASC->ApplyGameplayEffectSpecToSelf(*SpecHandle.Data.Get());
}

void ARinCBaseGameState::GrantRetrievedCartridges()
{
    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(BasePlayerController)) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = BasePlayerController->GetPartyInventoryComponent();
    if (!IsValid(PartyInventoryComponent)) return;

    if (RetrievedCartridges.IsEmpty()) return;

    OnCartirdgesGranted.Broadcast();

    PartyInventoryComponent->StoreCartridges(RetrievedCartridges);
    RetrievedCartridges.Empty();
}

void ARinCBaseGameState::InitAliveCharactersLists()
{
    if (!CurrentBattleArena) return;

    CurrentAliveHeroCharacters = CurrentBattleArena->GetBattleHeroCharacters();
    CurrentAliveMonsterCharacters = CurrentBattleArena->GetBattleMonsterCharacters();
}

void ARinCBaseGameState::RemoveFromCurrentQueueTurnOrder(ARinCBaseCharacter* const CharacterToRemove)
{
    int32 RemoveId = CurrentQueueTurnOrder.Find(CharacterToRemove);

    if (CurrentQueueTurnOrder.IsValidIndex(RemoveId))
    {
        CurrentQueueTurnOrder.RemoveAt(RemoveId);
    }
}

bool ARinCBaseGameState::CheckDeadCharacters()
{
    return CurrentAliveHeroCharacters.IsEmpty() || CurrentAliveMonsterCharacters.IsEmpty();
}

void ARinCBaseGameState::RemoveFromAliveHeroCharacters(ARinCBaseCharacter* const CharacterToRemove)
{
    int32 RemoveId = CurrentAliveHeroCharacters.Find(CharacterToRemove);

    if (CurrentAliveHeroCharacters.IsValidIndex(RemoveId))
    {
        CurrentAliveHeroCharacters.RemoveAt(RemoveId);
    }

    RemoveFromCurrentQueueTurnOrder(CharacterToRemove);

    if (CheckDeadCharacters())
    {
        CharacterToRemove->OnCharacterDeath.AddUObject(this, &ThisClass::EndBattle, false);
    }
}

void ARinCBaseGameState::RemoveFromAliveMonsterCharacters(ARinCBaseCharacter* const CharacterToRemove)
{
    RetrieveCartridgesFromMonster(CharacterToRemove);

    int32 RemoveId = CurrentAliveMonsterCharacters.Find(CharacterToRemove);

    if (CurrentAliveMonsterCharacters.IsValidIndex(RemoveId))
    {
        CurrentAliveMonsterCharacters.RemoveAt(RemoveId);
    }

    RemoveFromCurrentQueueTurnOrder(CharacterToRemove);

    if (CheckDeadCharacters())
    {
        CharacterToRemove->OnCharacterDeath.AddUObject(this, &ThisClass::EndBattle, true);
    }
}

void ARinCBaseGameState::RetrieveCartridgesFromMonster(ARinCBaseCharacter* Monster)
{
    if (!IsValid(Monster)) return;

    URinCCartridgeComponent* MonsterCartridgeComponent = Monster->GetCartridgeComponent();
    if (!IsValid(MonsterCartridgeComponent)) return;

    TArray<ARinCBaseCartridge*> EquippedCartridges = MonsterCartridgeComponent->GetEquippedCartridges();
    for (ARinCBaseCartridge* Cartridge : EquippedCartridges)
    {
        Cartridge->Unequip(Monster->GetAbilitySystemComponent());
    }

    RetrievedCartridges.Append(EquippedCartridges);
}

void ARinCBaseGameState::EndBattle(bool bWon)
{
    ARinCBaseGameMode* const BaseGameMode = Cast<ARinCBaseGameMode>(UGameplayStatics::GetGameMode(this));
    if (!BaseGameMode) return;

    CurrentQueueTurnOrder.Empty();
    OnBattleEnded.Broadcast();

    BaseGameMode->EndBattle(bWon);
}