// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/Characters/RinCBaseCharacter.h"
#include "Engine/LocalPlayer.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/Controller.h"
#include "AbilitySystemComponent.h"
#include "GameplayAbilitySpecHandle.h"
#include "AttributeSets/RinCBaseAttributeSet.h"
#include "Helpers/RinCBaseAbilitySet.h"
#include "RinCCombatComponent.h"
#include "RinCCartridgeComponent.h"
#include "GameStates/RinCBaseGameState.h"
#include "Kismet/GameplayStatics.h"
#include "DataAssets/RinCCharacterBattleData.h"
#include "NiagaraFunctionLibrary.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "DataAssets/RinCCartridgeData.h"
#include "DataAssets/RinCAbilityData.h"
#include "Components/WidgetComponent.h"
#include "UI/BattleWidgets/RinCSelectionReticleWidget.h"

ARinCBaseCharacter::ARinCBaseCharacter()
{
    GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

    bUseControllerRotationPitch = false;
    bUseControllerRotationYaw = false;
    bUseControllerRotationRoll = false;

    GetCharacterMovement()->bOrientRotationToMovement = true;
    GetCharacterMovement()->RotationRate = FRotator(0.0f, 500.0f, 0.0f);

    GetCharacterMovement()->JumpZVelocity = 700.f;
    GetCharacterMovement()->AirControl = 0.35f;
    GetCharacterMovement()->MaxWalkSpeed = 500.f;
    GetCharacterMovement()->MinAnalogWalkSpeed = 20.f;
    GetCharacterMovement()->BrakingDecelerationWalking = 2000.f;
    GetCharacterMovement()->BrakingDecelerationFalling = 1500.0f;

    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);
    CameraBoom->TargetArmLength = 400.0f;	
    CameraBoom->bUsePawnControlRotation = true;

    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
    FollowCamera->bUsePawnControlRotation = false;

    AbilitySystemComponent = CreateDefaultSubobject<UAbilitySystemComponent>(TEXT("AbilitySystemComponent"));
    CombatComponent = CreateDefaultSubobject<URinCCombatComponent>(TEXT("CombatComponent"));
    CartridgeComponent = CreateDefaultSubobject<URinCCartridgeComponent>(TEXT("CartridgeComponent"));

    SelectionReticleWidgetComponent = CreateDefaultSubobject<UWidgetComponent>(TEXT("SelectionReticleWidgetComponent"));
    SelectionReticleWidgetComponent->SetupAttachment(RootComponent);

    SelectionReticleWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
    SelectionReticleWidgetComponent->SetDrawSize(FVector2D(110.0f, 110.0f));
}

void ARinCBaseCharacter::BeginPlay()
{
    Super::BeginPlay();

    if (IsValid(AbilitySystemComponent))
    {
        AttributeSet = AbilitySystemComponent->GetSet<URinCBaseAttributeSet>();
        AbilitySystemComponent->AddLooseGameplayTag(CharacterBattleData->CharacterElementTag);
    }

    if (IsValid(InitialAbilitySet)) InitiallyGrantedAbilitySpecHandles.Append(InitialAbilitySet->GrantAbilitiesToAbilitySystem(AbilitySystemComponent));

    AbilitySystemComponent->GetGameplayAttributeValueChangeDelegate(AttributeSet->GetHealthAttribute()).AddUObject(this, &ARinCBaseCharacter::HealthChanged);
    AbilitySystemComponent->GetGameplayAttributeValueChangeDelegate(AttributeSet->GetMoraleAttribute()).AddUObject(this, &ARinCBaseCharacter::MoraleChanged);
    AbilitySystemComponent->GetGameplayAttributeValueChangeDelegate(AttributeSet->GetEnergyAttribute()).AddUObject(this, &ARinCBaseCharacter::EnergyChanged);
    AbilitySystemComponent->GetGameplayAttributeValueChangeDelegate(AttributeSet->GetActionPointsAttribute()).AddUObject(this, &ARinCBaseCharacter::ActionPointsChanged);
}

FPrimaryAssetId ARinCBaseCharacter::GetDataPrimaryAssetId()
{
    return CharacterDataPrimaryAssetId;
}

void ARinCBaseCharacter::SpawnDeathNiagara()
{
    if (!IsValid(CharacterBattleData)) return ;

    UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), CharacterBattleData->DeathNiagara, GetActorLocation());
}

void ARinCBaseCharacter::SetSelectionReticleState(bool bIsActive)
{
    URinCSelectionReticleWidget* SelectionReticleWidget = Cast<URinCSelectionReticleWidget>(SelectionReticleWidgetComponent->GetWidget());
    if (!IsValid(SelectionReticleWidget)) return;

    if (bIsActive)
    {
        SelectionReticleWidget->Activate();
    }
    else
    {
        SelectionReticleWidget->Deactivate();
    }
}
    
void ARinCBaseCharacter::HealthChanged(const FOnAttributeChangeData& Data)
{
    if (!IsValid(AttributeSet)) return;

    float CurrentHealth = Data.NewValue;

    OnHealthChanged.Broadcast(CurrentHealth, AttributeSet->GetHealthMax());

    if (FMath::IsNearlyEqual(CurrentHealth, 0.0))
    {
        HandleDeath();
        return;
    }

    if (CurrentHealth < Data.OldValue)
    {
        ExecuteHitReaction();
    }
    /*else if (CurrentHealth > Data.OldValue && FMath::IsNearlyEqual(Data.OldValue, 0.0))
    {
        CombatComponent->SpawnFloatingTextActorAsNumber(CurrentHealth - Data.OldValue, FColor::Green, GetActorTransform());
    }*/
}

void ARinCBaseCharacter::MoraleChanged(const FOnAttributeChangeData& Data)
{
    if (!IsValid(AttributeSet)) return;

    float CurrentMorale = Data.NewValue;

    OnMoraleChanged.Broadcast(CurrentMorale, AttributeSet->GetMoraleMax(), AttributeSet->GetMoraleThreshold());
}

void ARinCBaseCharacter::EnergyChanged(const FOnAttributeChangeData& Data)
{
    float CurrentEnergy = Data.NewValue;

    OnEnergyChanged.Broadcast(CurrentEnergy);
}

void ARinCBaseCharacter::ActionPointsChanged(const FOnAttributeChangeData& Data)
{
    float CurrentActionPoints = Data.NewValue;

    OnActionPointsChanged.Broadcast(CurrentActionPoints);
}

void ARinCBaseCharacter::HandleDeath()
{
#if UE_EDITOR
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Character is dead!"));
#endif // UE_EDITOR
}

void ARinCBaseCharacter::ExecuteHitReaction()
{
    if (!IsValid(CharacterBattleData)) return;

    PlayAnimMontage(GetRandomMontageFromArray(CharacterBattleData->HitReactMontages));
}

URinCCombatComponent* ARinCBaseCharacter::GetCombatComponent() const
{
    return CombatComponent;
}

const URinCBaseAttributeSet* ARinCBaseCharacter::GetBaseAttributeSet() const
{
    return AttributeSet;
}

UAbilitySystemComponent* ARinCBaseCharacter::GetAbilitySystemComponent() const
{
    return AbilitySystemComponent;
}

UAnimMontage* ARinCBaseCharacter::GetBuffMontage()
{
    if (!IsValid(CharacterBattleData)) return nullptr;

    return GetRandomMontageFromArray(CharacterBattleData->BuffMontages);
}

UAnimMontage* ARinCBaseCharacter::GetAttackMontage()
{
    if (!IsValid(CharacterBattleData)) return nullptr;

    return GetRandomMontageFromArray(CharacterBattleData->AttackMontages);
}

UAnimMontage* ARinCBaseCharacter::GetDeathMontage()
{
    if (!IsValid(CharacterBattleData)) return nullptr;

    return GetRandomMontageFromArray(CharacterBattleData->DeathMontages);
}

UAnimMontage* ARinCBaseCharacter::GetRandomMontageFromArray(TArray<UAnimMontage*> Montages)
{
    if (Montages.IsEmpty()) return nullptr;

    int32 MontageId = FMath::RandRange(0, Montages.Num() - 1);

    if (!Montages.IsValidIndex(MontageId)) return Montages.Last();

    return Montages[MontageId];
}

TArray<URinCAbilityData*> ARinCBaseCharacter::GetAllCurrentAbilities()
{
    if (!IsValid(InitialAbilitySet) || !IsValid(CartridgeComponent)) return TArray<URinCAbilityData*>();

    TArray<URinCAbilityData*> CurrentlyGrantedAbilities;

    /* Grab character's abilities */
    for (const FRinCAbilityToGrant& AbilitySetItem : InitialAbilitySet->AbilitySetItems)
    {
        CurrentlyGrantedAbilities.Add(AbilitySetItem.GameplayAbilityData);
    }

    /* Grab abilities granted by the equipped cartridges */
    for (ARinCBaseCartridge* EquippedCartridge : CartridgeComponent->GetEquippedCartridges())
    {
        URinCCartridgeData* CartridgeData = EquippedCartridge->GetCartridgeData();
        if (!IsValid(CartridgeData)) continue;

        if (!IsValid(CartridgeData->GameplayAbilityDataToGrant)) continue;

        CurrentlyGrantedAbilities.Add(CartridgeData->GameplayAbilityDataToGrant);
    }

    return CurrentlyGrantedAbilities;
}
