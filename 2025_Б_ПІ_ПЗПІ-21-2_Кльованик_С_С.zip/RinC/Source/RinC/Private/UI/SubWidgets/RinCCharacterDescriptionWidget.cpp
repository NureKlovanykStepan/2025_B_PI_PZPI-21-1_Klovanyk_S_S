// My copyright notice

#include "UI/SubWidgets/RinCCharacterDescriptionWidget.h"
#include "Characters/RinCBaseCharacter.h"
#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"
#include "Components/RichTextBlock.h"

void URinCCharacterDescriptionWidget::UpdateDescription(UObject* CharacterObject, URinCObjectSlotWidget* ClickedSlot)
{
    ARinCBaseCharacter* Character = Cast<ARinCBaseCharacter>(CharacterObject);
    if (!IsValid(Character)) return;

    const URinCBaseAttributeSet* CharacterAttributeSet = Character->GetBaseAttributeSet();
    if (!IsValid(CharacterAttributeSet)) return;

    UpdateCharacterStatsText(CharacterAttributeSet);
}

void URinCCharacterDescriptionWidget::UpdateCharacterStatsText(const URinCBaseAttributeSet* CharacterAttributeSet)
{
    if (!IsValid(CharacterAttributeSet)) return;

    FString FormattedStatsString;

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Health\"/>Health"), CharacterAttributeSet->GetHealthMax());

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Morale\"/>Morale Threshold"), CharacterAttributeSet->GetMoraleThreshold(), true); // Percentage-based

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Energy\"/>Energy"), CharacterAttributeSet->GetEnergyBase());

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Attack\"/>Attack"), CharacterAttributeSet->GetAttack());
    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Speed\"/>Speed"), CharacterAttributeSet->GetSpeed());
    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Defense\"/>Defense"), CharacterAttributeSet->GetDefense(), true); // Percentage-based

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Crit\"/>Crit Chance"), CharacterAttributeSet->GetCritChance(), true); // Percentage-based
    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Dodge\"/>Dodge Chance"), CharacterAttributeSet->GetDodgeChance(), true); // Percentage-based

    AppendStatToString(FormattedStatsString, TEXT("<img id=\"Action\"/>Action Points"), CharacterAttributeSet->GetActionPointsMax());

    StatsRichText->SetText(FText::FromString(FormattedStatsString));
}

void URinCCharacterDescriptionWidget::AppendStatToString(FString& OutString, const FString& StatName, float Value, bool bIsPercentage)
{
    if (!OutString.IsEmpty()) OutString.Append(TEXT("\n"));

    if (bIsPercentage)
    {
        OutString.Append(FString::Printf(TEXT("%s: %.1f%%"), *StatName, Value));
    }
    else
    {
        OutString.Append(FString::Printf(TEXT("%s: %.1f"), *StatName, Value));
    }
}

void URinCCharacterDescriptionWidget::AppendStatToString(FString& OutString, const FString& StatName, float Value)
{
    AppendStatToString(OutString, StatName, Value, false);
}