// My copyright notice

#include "UI/SubWidgets/RinCCharacterSideMenuWidget.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "Characters/RinCBaseHeroCharacter.h"

void URinCCharacterSideMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    CurrentCharacterSlots.Add(CurrentCharacter1);
    CurrentCharacterSlots.Add(CurrentCharacter2);
    CurrentCharacterSlots.Add(CurrentCharacter3);
}

void URinCCharacterSideMenuWidget::UpdateCurrentCharacterSlots(const TArray<ARinCBaseHeroCharacter*>& CurrentHeroCharacters, bool bShowPortrait)
{
    int32 Length = FMath::Min(CurrentHeroCharacters.Num(), CurrentCharacterSlots.Num());
    for (int32 i = 0; i < Length; i++)
    {
        if(CurrentCharacterSlots[i]) CurrentCharacterSlots[i]->SetStoredObject(CurrentHeroCharacters[i], bShowPortrait);
    }
}

