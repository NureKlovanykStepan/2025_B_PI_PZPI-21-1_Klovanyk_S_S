// My copyright notice

#include "UI/BattleWidgets/RinCBattleGameHUDWidget.h"
#include "UI/BattleWidgets/RinCHeroStatusWidget.h"
#include "Core/Controllers/RinCBasePlayerController.h"
#include "RinCPartyInventoryComponent.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "GameStates/RinCBaseGameState.h"
#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"
#include "Components/TextBlock.h"
#include "Components/HorizontalBox.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "DataAssets/RinCAbilityData.h"

void URinCBattleGameHUDWidget::NativeConstruct()
{
    Super::NativeConstruct();

    checkf(SlotWidgetClass, TEXT("SlotWidgetClass should be set!"))

    HeroStatuses.Add(HeroStatus1);
    HeroStatuses.Add(HeroStatus2);
    HeroStatuses.Add(HeroStatus3);

    BindAndUpdateHeroes();

    ARinCBaseGameState* BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (!IsValid(BaseGameState)) return;

    BaseGameState->OnTurnStart.AddUObject(this, &ThisClass::UpdateHeroTurnInfo);
}

void URinCBattleGameHUDWidget::BindAndUpdateHeroes()
{
    ARinCBasePlayerController* OwningController = GetOwningPlayer<ARinCBasePlayerController>();
    if (!IsValid(OwningController)) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = OwningController->GetPartyInventoryComponent();
    if (!IsValid(PartyInventoryComponent)) return;

    TArray<ARinCBaseHeroCharacter*> Heroes = PartyInventoryComponent->GetCurrentPartyHeroes();

    for (int32 i = 0; i < Heroes.Num(); i++)
    {
        if (!Heroes.IsValidIndex(i) || !IsValid(Heroes[i]) || !HeroStatuses.IsValidIndex(i) || !IsValid(HeroStatuses[i])) continue;

        HeroStatuses[i]->UpdateCharacterSlot(Heroes[i]);

        Heroes[i]->OnHealthChanged.AddUObject(HeroStatuses[i], &URinCHeroStatusWidget::UpdateHealth);
        Heroes[i]->OnMoraleChanged.AddUObject(HeroStatuses[i], &URinCHeroStatusWidget::UpdateMorale);
        Heroes[i]->OnEnergyChanged.AddUObject(HeroStatuses[i], &URinCHeroStatusWidget::UpdateEnergy);

        Heroes[i]->OnActionPointsChanged.AddUObject(this, &ThisClass::UpdateActionPoints);

        /* Update stats initially */
        const URinCBaseAttributeSet* AttributeSet = Heroes[i]->GetBaseAttributeSet();
        if (!IsValid(AttributeSet)) continue;

        HeroStatuses[i]->UpdateHealth(AttributeSet->GetHealth(), AttributeSet->GetHealthMax());
        HeroStatuses[i]->UpdateMorale(AttributeSet->GetMorale(), AttributeSet->GetMoraleMax(), AttributeSet->GetMoraleThreshold());
        HeroStatuses[i]->UpdateEnergy(AttributeSet->GetEnergy());
    }
}

void URinCBattleGameHUDWidget::UpdateHeroTurnInfo(ARinCBaseCharacter* TurnCharacter)
{
    if (!IsValid(TurnCharacter)) return;

    if (!TurnCharacter->IsA<ARinCBaseHeroCharacter>())
    {
        ActionPointsText->SetVisibility(ESlateVisibility::Hidden);
        AbilitiesHorizontalBox->ClearChildren();
        return;
    }

    ActionPointsText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

    const URinCBaseAttributeSet* AttributeSet = TurnCharacter->GetBaseAttributeSet();
    if (!IsValid(AttributeSet)) return;

    UpdateActionPoints(AttributeSet->GetActionPoints());

    UpdateGrantedAbilities(TurnCharacter->GetAllCurrentAbilities());
}

void URinCBattleGameHUDWidget::UpdateActionPoints(float NewActionPoints)
{
    FString OutputString;
    OutputString.Append(FString("Action Points: "));
    OutputString.Append(FString::FormatAsNumber(FMath::FloorToInt(NewActionPoints)));

    ActionPointsText->SetText(FText::FromString(OutputString));
}

void URinCBattleGameHUDWidget::UpdateGrantedAbilities(const TArray<URinCAbilityData*>& CurrentlyGrantedAbilities)
{
    AbilitiesHorizontalBox->ClearChildren();

    for (URinCAbilityData* AbilityData : CurrentlyGrantedAbilities)
    {
        URinCObjectSlotWidget* AbilitySlotWidget = CreateWidget<URinCObjectSlotWidget>(this, SlotWidgetClass);
        if (!IsValid(AbilitySlotWidget)) continue;

        AbilitiesHorizontalBox->AddChildToHorizontalBox(AbilitySlotWidget);

        AbilitySlotWidget->SetStoredObject(AbilityData);

        //AbilitySlotWidget->OnSlotClickedLMB.AddUObject(this, &ThisClass::UpdateAbilityDescription);
    }
}
