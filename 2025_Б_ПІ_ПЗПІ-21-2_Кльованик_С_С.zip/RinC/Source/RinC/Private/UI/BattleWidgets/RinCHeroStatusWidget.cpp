// My copyright notice

#include "UI/BattleWidgets/RinCHeroStatusWidget.h"
#include "Components/TextBlock.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "Characters/RinCBaseCharacter.h"

void URinCHeroStatusWidget::UpdateEnergy(float NewEnergy)
{
    float MaxDisplayEnergy = 9999.0f;
    CurrentEnergyText->SetText(FText::AsNumber(FMath::Min(NewEnergy, MaxDisplayEnergy)));
}

void URinCHeroStatusWidget::UpdateCharacterSlot(ARinCBaseCharacter* SlotCharacter)
{
    CharacterSlot->SetStoredObject(SlotCharacter);
}
