// My copyright notice

#include "UI/Widgets/RinCButtonWidget.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"

void URinCButtonWidget::NativeConstruct()
{
    Super::NativeConstruct();

    if (BaseButton)
    {
        BaseButton->OnClicked.AddUniqueDynamic(this, &URinCButtonWidget::BroadcastButtonClick);
    }
}

void URinCButtonWidget::BroadcastButtonClick()
{
    OnButtonClicked.Broadcast();
}
