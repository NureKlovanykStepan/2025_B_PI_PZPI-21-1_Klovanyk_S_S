// My copyright notice

#include "UI/Widgets/RinCPrimaryLayoutWidget.h"
#include "UI/Widgets/RinCBaseLayerWidget.h"

void URinCPrimaryLayoutWidget::NativeConstruct()
{
    Super::NativeConstruct();

    /* LayersMap should be populated in a blueprint child's native construct */
}

void URinCPrimaryLayoutWidget::PushInitialScreens()
{
    for (const auto& kv : InitialScreens)
    {
        PushContentToLayer(kv.Key, kv.Value, false);
    }
}

void URinCPrimaryLayoutWidget::RegisterLayer(ERinCLayerType LayerType, URinCBaseLayerWidget* LayerWidget)
{
    if (LayersMap.Contains(LayerType)) return;

    LayersMap.Add(LayerType, LayerWidget);
}

void URinCPrimaryLayoutWidget::UnRegisterLayer(ERinCLayerType LayerType)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return;

    Layer->RemoveFromParent();

    LayersMap.Remove(LayerType);
}

void URinCPrimaryLayoutWidget::PushContentToLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass, bool bShowPushedContent)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return;

    Layer->PushContent(SoftWidgetClass, bShowPushedContent);
}

void URinCPrimaryLayoutWidget::PushContentToLayerWithCheck(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return;

    Layer->PushContentWithCheck(SoftWidgetClass);
}

bool URinCPrimaryLayoutWidget::IsContentCollapsedInLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return false;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return false;

    return Layer->IsContentCollapsed(SoftWidgetClass);
}

void URinCPrimaryLayoutWidget::PopContentFromLayer(ERinCLayerType LayerType)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return;

    Layer->PopContent();
}

void URinCPrimaryLayoutWidget::CollapseContentInLayer(ERinCLayerType LayerType)
{
    URinCBaseLayerWidget** const LayerPtr = LayersMap.Find(LayerType);
    if (!LayerPtr) return;

    URinCBaseLayerWidget* const Layer = *LayerPtr;
    if (!Layer) return;

    Layer->CollapseTop();
}
