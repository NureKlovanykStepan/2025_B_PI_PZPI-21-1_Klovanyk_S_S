// My copyright notice

#include "UI/GameMenus/RinCBaseGameMenuWidget.h"
#include "RinCPartyInventoryComponent.h"
#include "Controllers/RinCBasePlayerController.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "UI/SubWidgets/RinCCharacterSideMenuWidget.h"
#include "Characters/RinCBaseCharacter.h"
#include "Components/TextBlock.h"
#include "DataAssets/RinCBaseData.h"
#include "Miscellaneous/RinCResourceLoader.h"

void URinCBaseGameMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    if (!CharacterContainerWidget) return;

    for (URinCObjectSlotWidget* CharacterSlot : CharacterContainerWidget->GetCurrentCharacterSlots())
    {
        CharacterSlot->OnSlotClickedLMB.AddUObject(this, &ThisClass::OnCharacterSlotClickedLMB);
    }
}

void URinCBaseGameMenuWidget::HandleVisibilityChanged(ESlateVisibility InVisibility)
{
    if (InVisibility == ESlateVisibility::Collapsed || InVisibility == ESlateVisibility::Hidden) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    UpdateCurrentCharacters(PartyInventoryComponent->GetCurrentPartyHeroes());
}

void URinCBaseGameMenuWidget::OnCharacterSlotClickedLMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    HandleCharacterSlotSelect(StoredObject, ClickedSlot);
}

void URinCBaseGameMenuWidget::HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    if (!ClickedSlot) return;

    SelectedCharacter = Cast<ARinCBaseCharacter>(StoredObject);

    if (!IsValid(CharacterContainerWidget)) return;

    DeactivateSlots(CharacterContainerWidget->GetCurrentCharacterSlots());

    ClickedSlot->SetIsActive(true);

    UpdateSelectedCharacter();
}

void URinCBaseGameMenuWidget::UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters)
{
    if (!IsValid(CharacterContainerWidget)) return;

    CharacterContainerWidget->UpdateCurrentCharacterSlots(CurrentHeroCharacters);

    TArray<URinCObjectSlotWidget*> CurrentCharacterSlots = CharacterContainerWidget->GetCurrentCharacterSlots();

    if (CurrentCharacterSlots.IsEmpty() || CurrentHeroCharacters.IsEmpty()) return;

    /* Select the first character slot by default */
    URinCObjectSlotWidget* CharacterSlotToSelect = CurrentCharacterSlots[0];
    if (!CharacterSlotToSelect) return;

    HandleCharacterSlotSelect(CharacterSlotToSelect->GetStoredObject(), CharacterSlotToSelect);
}

URinCPartyInventoryComponent* URinCBaseGameMenuWidget::GetPartyInventoryComponent() const
{
    ARinCBasePlayerController* PlayerController = GetOwningPlayer<ARinCBasePlayerController>();
    if (!PlayerController) return nullptr;

    return PlayerController->GetPartyInventoryComponent();
}

void URinCBaseGameMenuWidget::DeactivateSlots(const TArray<URinCObjectSlotWidget*>& SlotsToDeactivate)
{
    for (URinCObjectSlotWidget* SlotToDeactivate : SlotsToDeactivate)
    {
        if (!SlotToDeactivate) continue;

        SlotToDeactivate->SetIsActive(false);
    }
}

void URinCBaseGameMenuWidget::ClearSlots(const TArray<URinCObjectSlotWidget*>& SlotsToClear)
{
    for (URinCObjectSlotWidget* SlotToClear : SlotsToClear)
    {
        if (!SlotToClear) continue;

        SlotToClear->ClearSlot();
    }
}

void URinCBaseGameMenuWidget::UpdateSelectedCharacterNameText(FPrimaryAssetId LoadedId)
{
    URinCBaseData* const Data = Cast<URinCBaseData>(RinCResourceLoader::GetPrimaryAssetObject(LoadedId));
    if (!IsValid(Data)) return;

    SelectedCharacterNameText->SetText(Data->DisplayName);
}

void URinCBaseGameMenuWidget::UpdateSelectedCharacter()
{
    if (!IsValid(SelectedCharacter)) return;

    FPrimaryAssetId CharacterDataId = SelectedCharacter->GetDataPrimaryAssetId();

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCBaseData>(CharacterDataId, TArray<FName>(),
        this, &ThisClass::UpdateSelectedCharacterNameText, CharacterDataId);
}
