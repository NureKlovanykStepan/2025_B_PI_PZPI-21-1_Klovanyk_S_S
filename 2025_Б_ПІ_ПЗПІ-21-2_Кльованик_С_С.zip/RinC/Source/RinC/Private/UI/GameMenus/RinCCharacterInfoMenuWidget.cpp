// My copyright notice

#include "UI/GameMenus/RinCCharacterInfoMenuWidget.h"
#include "UI/SubWidgets/RinCCharacterDescriptionWidget.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "GASClasses/Helpers/RinCBaseAbilitySet.h"
#include "RinCCartridgeComponent.h"
#include "Characters/RinCBaseCharacter.h"
#include "DataAssets/RinCAbilityData.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "DataAssets/RinCCartridgeData.h"
#include "Components/RichTextBlock.h"
#include "Components/VerticalBox.h"

void URinCCharacterInfoMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    checkf(SlotWidgetClass, TEXT("SlotWidgetClass should be set!"))
}

void URinCCharacterInfoMenuWidget::HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    Super::HandleCharacterSlotSelect(StoredObject, ClickedSlot);

    ARinCBaseCharacter* Character = Cast<ARinCBaseCharacter>(StoredObject);
    if (!IsValid(Character)) return;

    UpdateGrantedAbilities(Character->GetAllCurrentAbilities());

    if (!IsValid(CharacterDescriptionWidget)) return;
    CharacterDescriptionWidget->UpdateDescription(StoredObject, ClickedSlot);
}

void URinCCharacterInfoMenuWidget::UpdateGrantedAbilities(const TArray<URinCAbilityData*>& CurrentlyGrantedAbilities)
{
    AbilitiesVerticalBox->ClearChildren();

    for (URinCAbilityData* AbilityData : CurrentlyGrantedAbilities)
    {
        URinCObjectSlotWidget* AbilitySlotWidget = CreateWidget<URinCObjectSlotWidget>(this, SlotWidgetClass);
        if (!IsValid(AbilitySlotWidget)) continue;

        AbilitiesVerticalBox->AddChildToVerticalBox(AbilitySlotWidget);

        AbilitySlotWidget->SetStoredObject(AbilityData);

        AbilitySlotWidget->OnSlotClickedLMB.AddUObject(this, &ThisClass::UpdateAbilityDescription);
    }
}

void URinCCharacterInfoMenuWidget::UpdateAbilityDescription(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    URinCAbilityData* StoredAbilityData = Cast<URinCAbilityData>(StoredObject);
    if (!IsValid(StoredAbilityData)) return;

    FString DescriptionString;
    DescriptionString.Append(FString::Printf(TEXT("%s%s%s"), TEXT("<Header>"), *StoredAbilityData->DisplayName.ToString(), TEXT("</>")));
    DescriptionString.Append(TEXT("\n"));
    DescriptionString.Append(StoredAbilityData->Description.ToString());

    AbilityDescriptionRichText->SetText(FText::FromString(DescriptionString));
}
