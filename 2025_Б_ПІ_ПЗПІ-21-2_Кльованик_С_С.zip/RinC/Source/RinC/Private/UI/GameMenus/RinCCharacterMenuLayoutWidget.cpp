// My copyright notice

#include "UI/GameMenus/RinCCharacterMenuLayoutWidget.h"
#include "UI/GameMenus/RinCCharacterSetupMenuWidget.h"

void URinCCharacterMenuLayoutWidget::NativeConstruct()
{
    OnVisibilityChanged.AddUniqueDynamic(CharacterSetupMenuWidget, &URinCCharacterSetupMenuWidget::HandleVisibilityChanged);
}
