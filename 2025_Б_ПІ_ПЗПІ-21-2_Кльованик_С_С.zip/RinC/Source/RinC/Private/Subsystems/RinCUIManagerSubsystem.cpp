// My copyright notice

#include "Subsystems/RinCUIManagerSubsystem.h"
#include "UI/Widgets/RinCPrimaryLayoutWidget.h"
#include "UI/Widgets/RinCBaseLayerWidget.h"

void URinCUIManagerSubsystem::RegisterLayer(ERinCLayerType LayerType, URinCBaseLayerWidget* LayerWidget)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->RegisterLayer(LayerType, LayerWidget);
}

void URinCUIManagerSubsystem::UnRegisterLayer(ERinCLayerType LayerType)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->UnRegisterLayer(LayerType);
}

void URinCUIManagerSubsystem::PushContentToLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->PushContentToLayer(LayerType, SoftWidgetClass);
}

void URinCUIManagerSubsystem::PushContentToLayerWithCheck(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->PushContentToLayerWithCheck(LayerType, SoftWidgetClass);
}

bool URinCUIManagerSubsystem::IsContentCollapsedInLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return false;

    return PrimaryLayoutWidget->IsContentCollapsedInLayer(LayerType, SoftWidgetClass);
}

void URinCUIManagerSubsystem::PopContentFromLayer(ERinCLayerType LayerType)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->PopContentFromLayer(LayerType);
}

void URinCUIManagerSubsystem::CollapseContentInLayer(ERinCLayerType LayerType)
{
    URinCPrimaryLayoutWidget* const PrimaryLayoutWidget = WeakPrimaryLayoutWidget.Get();
    if (!IsValid(PrimaryLayoutWidget)) return;

    PrimaryLayoutWidget->CollapseContentInLayer(LayerType);
}
