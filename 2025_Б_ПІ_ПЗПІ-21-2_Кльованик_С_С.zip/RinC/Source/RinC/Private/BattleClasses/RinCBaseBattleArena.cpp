// Fill out your copyright notice in the Description page of Project Settings.

#include "BattleClasses/RinCBaseBattleArena.h"
#include "Components/BoxComponent.h"
#include "Kismet/GameplayStatics.h"
#include "RinCBaseBattlePosition.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "Controllers/RinCBasePlayerController.h"
#include "GameModes/RinCBaseGameMode.h"
#include "RinCPartyInventoryComponent.h"
#include "Characters/RinCBaseMonsterCharacter.h"
#include "Miscellaneous/RinCResourceLoader.h"
#include "DataAssets/RinCCartridgeData.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "RinCCartridgeComponent.h"

DEFINE_LOG_CATEGORY(LogARinCBaseBattleArena);

ARinCBaseBattleArena::ARinCBaseBattleArena()
    : bIsArenaDisabled(false)
{
    PrimaryActorTick.bCanEverTick = false;

    BattleArenaOverlapBox = CreateDefaultSubobject<UBoxComponent>(TEXT("BattleArenaOverlapBox"));
    SetRootComponent(BattleArenaOverlapBox);

    BattleArenaOverlapBox->SetBoxExtent(FVector(200.0f, 200.0f, 100.0f));

    BattleArenaOverlapBox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    BattleArenaOverlapBox->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
    BattleArenaOverlapBox->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic, ECollisionResponse::ECR_Overlap);
    BattleArenaOverlapBox->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Overlap);
    BattleArenaOverlapBox->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);
    BattleArenaOverlapBox->ShapeColor = FColor::Blue;

    BattleArenaOverlapBox->OnComponentBeginOverlap.AddDynamic(this, &ARinCBaseBattleArena::OnComponentBeginOverlap);
    bGenerateOverlapEventsDuringLevelStreaming = true;
}

void ARinCBaseBattleArena::BeginPlay()
{
	Super::BeginPlay();

    float TotalProbability = 0.0f;
    for (const FRinCMonsterSpawnInfo& SpawnInfo : MonsterPool)
    {
        TotalProbability += SpawnInfo.SpawnProbability;
    }

    checkf(FMath::IsNearlyEqual(TotalProbability, 100.0f), TEXT("MonsterPool's TotalProbability should be equal to 100.0!"))
}

void ARinCBaseBattleArena::AddBattlePosition(ARinCBaseBattlePosition* const BattlePosition)
{
    if (!BattlePosition) return;

    if (BattlePosition->GetIsHeroBattlePosition())
    {
        HeroBattlePositions.Add(BattlePosition);
        return;
    }

    MonsterBattlePositions.Add(BattlePosition);
}

void ARinCBaseBattleArena::SetupBattleArena()
{
    BattleCharacters.Empty();
    BattleHeroCharacters.Empty();
    BattleMonsterCharacters.Empty();

    OnPrepareBattleStarted.Broadcast();

    PositionHeroes();

    SetupMonsters();
}

void ARinCBaseBattleArena::TemporaryDisableArena(float Seconds)
{
    /* Additional cleanup */
    BattleCharacters.Empty();
    BattleHeroCharacters.Empty();
    for (ARinCBaseCharacter* MonsterCharacter : BattleMonsterCharacters)
    {
        if (!IsValid(MonsterCharacter)) continue;

        MonsterCharacter->Destroy();
    }
    BattleMonsterCharacters.Empty();

    MonsterLoadHandle.Reset();

    /* Disable the arena */
    bIsArenaDisabled = true;

    GetWorldTimerManager().SetTimer(
        RestoreCollisionTimerHandle,
        FTimerDelegate::CreateUObject(this, &ARinCBaseBattleArena::ReEnableArena),
        Seconds,
        false);
}

void ARinCBaseBattleArena::PositionHeroes()
{
    checkf(HeroBattlePositions.Num() == HeroesToPosition.Num(), TEXT("HeroBattlePositions amount should be equal to the HeroesToPosition amount!"))

    for (int32 i = 0; i < HeroBattlePositions.Num(); i++)
    {
        if (!IsValid(HeroBattlePositions[i])) continue;

        ARinCBaseCharacter* const PositionedCharacter = HeroBattlePositions[i]->PositionExistingBattleCharacter(HeroesToPosition[i]);
        if (!PositionedCharacter) continue;

        BattleCharacters.Add(PositionedCharacter);
        BattleHeroCharacters.Add(PositionedCharacter);
    }
}

void ARinCBaseBattleArena::SetupMonsters()
{
    TArray<FSoftObjectPath> SoftMonsterClassPaths;
    TArray<TSoftClassPtr<ARinCBaseMonsterCharacter>> SoftMonsterClasses;

    for (int32 i = 0; i < MonsterBattlePositions.Num(); i++)
    {
        TSoftClassPtr<ARinCBaseMonsterCharacter> SoftMonsterClass = GetRandomMonsterClass();

        SoftMonsterClasses.Add(SoftMonsterClass);
        SoftMonsterClassPaths.Add(SoftMonsterClass.ToSoftObjectPath());
    }

    FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(this, &ThisClass::SetupMonstersInternal, SoftMonsterClasses);
    MonsterLoadHandle = RinCResourceLoader::RequestAsyncLoad(SoftMonsterClassPaths, Delegate);
}

void ARinCBaseBattleArena::SetupMonstersInternal(TArray<TSoftClassPtr<ARinCBaseMonsterCharacter>> SoftMonsterClasses)
{
    PositionMonsters(SoftMonsterClasses);

    GrantRandomCartridgesToMonsters();

    OnPrepareBattleEnded.Broadcast();
}

void ARinCBaseBattleArena::PositionMonsters(const TArray<TSoftClassPtr<ARinCBaseMonsterCharacter>>& SoftMonsterClasses)
{
    for (int32 i = 0; i < MonsterBattlePositions.Num(); i++)
    {
        if (!MonsterBattlePositions.IsValidIndex(i) || !IsValid(MonsterBattlePositions[i])) continue;

        ARinCBaseCharacter* PositionedCharacter = MonsterBattlePositions[i]->SpawnBattleMonsterFromLoadedClass(SoftMonsterClasses[i]);
        if (!IsValid(PositionedCharacter)) continue;

        BattleCharacters.Add(PositionedCharacter);
        BattleMonsterCharacters.Add(PositionedCharacter);
    }
}

void ARinCBaseBattleArena::GrantRandomCartridgesToMonsters()
{
    TArray<FPrimaryAssetId> CartridgeIds = GetRandomCartridgeIds();

    FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(this, &ThisClass::EquipLoadedCartridges, CartridgeIds);
    RinCResourceLoader::LoadPrimaryAssets(CartridgeIds, TArray<FName>(), Delegate);
}

TSoftClassPtr<ARinCBaseMonsterCharacter> ARinCBaseBattleArena::GetRandomMonsterClass()
{
    checkf(!MonsterPool.IsEmpty(), TEXT("MonsterPool shouldn't be empty!"))

    MonsterPool.Sort([](const FRinCMonsterSpawnInfo& SpawnInfo1, const FRinCMonsterSpawnInfo& SpawnInfo2)
    {
        return SpawnInfo1.SpawnProbability > SpawnInfo2.SpawnProbability; /* Ascending order by spawn probabilities*/
    });

    float TotalProbability = 0.0f;
    for (const FRinCMonsterSpawnInfo& SpawnInfo : MonsterPool)
    {
        TotalProbability += SpawnInfo.SpawnProbability;
    }

    if (TotalProbability <= 0.0f && MonsterPool.Num() > 0)
    {
        return MonsterPool.Last().MonsterSoftClass;
    }

    float RandomValue = FMath::RandRange(0.0f, TotalProbability);

    float AccumulatedProbability = 0.0f;
    for (const FRinCMonsterSpawnInfo& SpawnInfo : MonsterPool)
    {
        AccumulatedProbability += SpawnInfo.SpawnProbability;
        if (RandomValue <= AccumulatedProbability)
        {
            return SpawnInfo.MonsterSoftClass;
        }
    }

    return MonsterPool.Last().MonsterSoftClass;
}

TArray<FPrimaryAssetId> ARinCBaseBattleArena::GetRandomCartridgeIds()
{
    checkf(!CartridgePool.IsEmpty(), TEXT("CartridgePool shouldn't be empty!"))

    TArray<FPrimaryAssetId> Result;

    int32 NumToSelect = FMath::RandRange(1, CartridgePool.Num());

    Result.Reserve(NumToSelect);

    for (int32 i = 0; i < NumToSelect; i++)
    {
        int32 RandomIndex = FMath::RandRange(0, CartridgePool.Num() - 1);
        Result.Add(CartridgePool[RandomIndex]);
    }

    return Result;
}

void ARinCBaseBattleArena::EquipLoadedCartridges(TArray<FPrimaryAssetId> CartridgeDataIds)
{
    TArray<ARinCBaseCartridge*> CartridgesToEquip;
    CartridgesToEquip.Reserve(CartridgeDataIds.Num());

    for (const FPrimaryAssetId& InitialCartridgeDataId : CartridgeDataIds)
    {
        CartridgesToEquip.Add(SpawnCartridgeFromData(InitialCartridgeDataId));
    }

    DistributeCartridgesToEquipEvenly(CartridgesToEquip);
}

void ARinCBaseBattleArena::DistributeCartridgesToEquipEvenly(const TArray<ARinCBaseCartridge*>& CartridgesToEquip)
{
    if (BattleMonsterCharacters.IsEmpty() || CartridgesToEquip.IsEmpty()) return;

    /* Calculate how many cartridges each monster should get (minimum) */
    int32 CartridgesPerMonster = CartridgesToEquip.Num() / BattleMonsterCharacters.Num();

    /* Calculate how many monsters will get an extra cartridge */
    int32 RemainderCartridges = CartridgesToEquip.Num() % BattleMonsterCharacters.Num();

    int32 CurrentCartridgeIndex = 0;

    /* Distribute cartridges to monsters */
    for (int32 MonsterIndex = 0; MonsterIndex < BattleMonsterCharacters.Num(); MonsterIndex++)
    {
        if (!IsValid(BattleMonsterCharacters[MonsterIndex]))  continue;

        int32 CartridgesForThisMonster = CartridgesPerMonster;

        /* Distribute remainder cartridges (one extra to some monsters) */
        if (RemainderCartridges > 0)
        {
            CartridgesForThisMonster++;
            RemainderCartridges--;
        }

        for (int32 i = 0; i < CartridgesForThisMonster; i++)
        {
            if (CurrentCartridgeIndex >= CartridgesToEquip.Num()) break;

            if (!IsValid(CartridgesToEquip[CurrentCartridgeIndex])) continue;

            ARinCBaseCharacter* Monster = BattleMonsterCharacters[MonsterIndex];
            if (!IsValid(Monster)) continue;

            URinCCartridgeComponent* MonsterCartridgeComponent = Monster->GetCartridgeComponent();
            if (!IsValid(MonsterCartridgeComponent)) return;

            MonsterCartridgeComponent->AddEquippedCartridge(CartridgesToEquip[CurrentCartridgeIndex]);

            CurrentCartridgeIndex++;
        }
    }

    if (CurrentCartridgeIndex < CartridgesToEquip.Num())
    {
        UE_LOG(LogARinCBaseBattleArena, Warning, TEXT("%d cartridges were not equipped due to insufficient valid monsters."),
            CartridgesToEquip.Num() - CurrentCartridgeIndex);
    }
}

void ARinCBaseBattleArena::ReEnableArena()
{
    bIsArenaDisabled = false;

    if (!IsValid(GetWorld())) return;
    GetWorldTimerManager().ClearTimer(RestoreCollisionTimerHandle);
}

ARinCBaseCartridge* ARinCBaseBattleArena::SpawnCartridgeFromData(FPrimaryAssetId CartridgeDataId)
{
    UWorld* World = GetWorld();
    if (!IsValid(World)) return nullptr;

    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeDataId));
    if (!IsValid(CartridgeData)) return nullptr;

    /* Spawn a new cartridge instance and assign it with data */
    ARinCBaseCartridge* SpawnedCartridge = World->SpawnActorDeferred<ARinCBaseCartridge>(ARinCBaseCartridge::StaticClass(), FTransform());
    SpawnedCartridge->SetCartridgeDataPrimaryAssetId(CartridgeDataId);
    SpawnedCartridge->FinishSpawning(FTransform());

    CartridgeData->InitCartridgeStats(SpawnedCartridge);

    return SpawnedCartridge;
}

void ARinCBaseBattleArena::OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
    int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    if (bIsArenaDisabled) return;

    ARinCBaseHeroCharacter* const OverlappedCharacter = Cast<ARinCBaseHeroCharacter>(OtherActor);
    if (!OverlappedCharacter) return;

    ARinCBasePlayerController* const OverlappedPlayerController = Cast<ARinCBasePlayerController>(OverlappedCharacter->GetController());
    if (!OverlappedPlayerController) return;

    URinCPartyInventoryComponent* const PartyInventoryComponent = OverlappedPlayerController->GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    ARinCBaseGameMode* const BaseGameMode = Cast<ARinCBaseGameMode>(UGameplayStatics::GetGameMode(this));
    if (!BaseGameMode) return;

    /* Pass existing party heroes to position them later in this BattleArena */
    HeroesToPosition = PartyInventoryComponent->GetCurrentPartyHeroes();

    // TO DO handle this via GameState instead
    BaseGameMode->PrepareBattle(this);
}
