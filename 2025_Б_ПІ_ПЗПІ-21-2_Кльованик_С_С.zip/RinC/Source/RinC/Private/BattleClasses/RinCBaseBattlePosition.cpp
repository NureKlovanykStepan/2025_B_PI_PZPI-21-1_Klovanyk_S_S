// Fill out your copyright notice in the Description page of Project Settings.

#include "BattleClasses/RinCBaseBattlePosition.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Characters/RinCBaseCharacter.h"
#include "RinCBaseBattleArena.h"
#include "Characters/RinCBaseMonsterCharacter.h"

ARinCBaseBattlePosition::ARinCBaseBattlePosition()
    : bIsHeroBattlePosition(false)
{
    PrimaryActorTick.bCanEverTick = false;

    BattlePositionCapsule = CreateDefaultSubobject<UCapsuleComponent>(TEXT("BattlePositionCapsule"));
    SetRootComponent(BattlePositionCapsule);

    BattlePositionCapsule->InitCapsuleSize(42.0f, 96.0f);
    BattlePositionCapsule->SetShouldUpdatePhysicsVolume(false);

    BattlePositionCapsule->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    BattlePositionCapsule->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
    BattlePositionCapsule->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic, ECollisionResponse::ECR_Overlap);
    BattlePositionCapsule->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Overlap);
    BattlePositionCapsule->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);

    BattlePositionCapsule->bShouldCollideWhenPlacing = true;
    BattlePositionCapsule->Mobility = EComponentMobility::Static;
    bCollideWhenPlacing = true;
    SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
    BattlePositionCapsule->ShapeColor = FColor::Purple;

    BattlePositionCapsule->OnComponentBeginOverlap.AddDynamic(this, &ARinCBaseBattlePosition::OnComponentBeginOverlap);
    bGenerateOverlapEventsDuringLevelStreaming = true;
}

void ARinCBaseBattlePosition::BeginPlay()
{
	Super::BeginPlay();
}

ARinCBaseCharacter* ARinCBaseBattlePosition::SpawnBattleMonsterFromLoadedClass(TSoftClassPtr<ARinCBaseMonsterCharacter> MonsterSoftClass)
{
    UClass* MonsterClass = MonsterSoftClass.Get();
    if (!IsValid(MonsterClass)) return nullptr;

    return SpawnMonsterInternal(MonsterClass);
}

ARinCBaseCharacter* ARinCBaseBattlePosition::PositionExistingBattleCharacter(ARinCBaseCharacter* const Character)
{
    if (!Character) return nullptr;

    FVector BattlePositionLocation = GetActorLocation();
    FRotator BattlePositionRotation = GetActorRotation();

    Character->SetActorLocation(BattlePositionLocation);
    Character->SetActorRotation(BattlePositionRotation);

    /* Disable ExistingBattleCharacter movement*/
    UCharacterMovementComponent* CharacterMovement = Character->GetCharacterMovement();
    if (!CharacterMovement) return nullptr;

    CharacterMovement->DisableMovement();

    Character->SetActorHiddenInGame(false);
    Character->SetActorEnableCollision(true);

    return Character;
}

void ARinCBaseBattlePosition::OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    ARinCBaseBattleArena* const BattleArena = Cast<ARinCBaseBattleArena>(OtherActor);
    if (!BattleArena) return;

    BattleArena->AddBattlePosition(this);
}

ARinCBaseCharacter* ARinCBaseBattlePosition::SpawnMonsterInternal(UClass* MonsterClass)
{
    UWorld* World = GetWorld();
    if (!IsValid(World)) return nullptr;

    FVector BattlePositionLocation = GetActorLocation();
    FRotator BattlePositionRotation = GetActorRotation();

    FActorSpawnParameters SpawnParams;
    SpawnParams.Owner = this;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    ARinCBaseCharacter* SpawnedMonster = World->SpawnActor<ARinCBaseCharacter>(
        MonsterClass,
        BattlePositionLocation,
        BattlePositionRotation,
        SpawnParams
    );

    return SpawnedMonster;
}
