// Fill out your copyright notice in the Description page of Project Settings.

#include "BattleClasses/RinCBattleHelperHeroOpposite.h"
#include "Components/CapsuleComponent.h"
#include "RinCBaseBattleArena.h"

ARinCBattleHelperHeroOpposite::ARinCBattleHelperHeroOpposite()
{
    PrimaryActorTick.bCanEverTick = false;

    HelperHeroOppositeCapsule = CreateDefaultSubobject<UCapsuleComponent>(TEXT("HelperHeroOppositeCapsule"));
    SetRootComponent(HelperHeroOppositeCapsule);

    HelperHeroOppositeCapsule->InitCapsuleSize(42.0f, 96.0f);
    HelperHeroOppositeCapsule->SetShouldUpdatePhysicsVolume(false);

    HelperHeroOppositeCapsule->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    HelperHeroOppositeCapsule->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
    HelperHeroOppositeCapsule->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic, ECollisionResponse::ECR_Overlap);
    HelperHeroOppositeCapsule->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Overlap);
    HelperHeroOppositeCapsule->SetCollisionObjectType(ECollisionChannel::ECC_WorldStatic);

    HelperHeroOppositeCapsule->bShouldCollideWhenPlacing = true;
    HelperHeroOppositeCapsule->Mobility = EComponentMobility::Static;
    bCollideWhenPlacing = true;
    SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
    HelperHeroOppositeCapsule->ShapeColor = FColor::Orange;

    HelperHeroOppositeCapsule->OnComponentBeginOverlap.AddDynamic(this, &ARinCBattleHelperHeroOpposite::OnComponentBeginOverlap);
    bGenerateOverlapEventsDuringLevelStreaming = true;

}

void ARinCBattleHelperHeroOpposite::BeginPlay()
{
	Super::BeginPlay();
}

void ARinCBattleHelperHeroOpposite::OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    ARinCBaseBattleArena* const BattleArena = Cast<ARinCBaseBattleArena>(OtherActor);
    if (!BattleArena) return;

    BattleArena->SetBattleHelperHeroOpposite(this);
}


