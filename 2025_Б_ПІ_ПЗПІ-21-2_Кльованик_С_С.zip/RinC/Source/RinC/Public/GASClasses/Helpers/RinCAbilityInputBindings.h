// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GASClasses/Helpers/RinCAbilityInput.h"
#include "RinCAbilityInputBindings.generated.h"

struct FInputActionValue;
class UInputAction;

USTRUCT()
struct FRinCAbilityInputToInputActionBinding
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly)
    UInputAction* InputAction;

    UPROPERTY(EditDefaultsOnly)
    ERinCAbilityInput AbilityInput;
};

UCLASS()
class RINC_API URinCAbilityInputBindings : public UDataAsset
{
	GENERATED_BODY()
	
public:
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Input")
    TArray<FRinCAbilityInputToInputActionBinding> Bindings;
};
