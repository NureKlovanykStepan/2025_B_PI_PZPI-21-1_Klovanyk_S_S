// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "RinCAbilityInput.h"
#include "RinCBaseAbilitySet.generated.h"

class UGameplayAbility;
class UAbilitySystemComponent;
struct FGameplayAbilitySpecHandle;
class URinCAbilityData;

USTRUCT()
struct FRinCAbilityToGrant
{
    GENERATED_BODY()

public:
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Ability")
    URinCAbilityData* GameplayAbilityData;

    UPROPERTY(EditDefaultsOnly, Category = "RinC|Ability")
    ERinCAbilityInput InputKey;
};

UCLASS()
class RINC_API URinCBaseAbilitySet : public UDataAsset
{
	GENERATED_BODY()

public:
    TArray<FGameplayAbilitySpecHandle> GrantAbilitiesToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent) const;
	
public:
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Ability")
    TArray<FRinCAbilityToGrant> AbilitySetItems;
};
