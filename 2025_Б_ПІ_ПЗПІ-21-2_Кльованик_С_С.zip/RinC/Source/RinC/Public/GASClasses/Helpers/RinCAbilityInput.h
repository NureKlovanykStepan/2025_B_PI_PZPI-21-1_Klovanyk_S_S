#pragma once

UENUM(BlueprintType)
enum class ERinCAbilityInput : uint8
{
    None = 0 UMETA(Hidden),
    PrimaryAbility,
    SecondaryAbility,
    WeaponAbility,
    ArmorAbility
};