// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "GameplayModMagnitudeCalculation.h"
#include "RinCEnergyCostMagCalc.generated.h"

UCLASS()
class RINC_API URinCEnergyCostMagCalc : public UGameplayModMagnitudeCalculation
{
	GENERATED_BODY()
	
protected:
    float CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const override;

};
