// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameplayModMagnitudeCalculation.h"
#include "RinCCalculateDamageMagCalc.generated.h"

class URinCElementalScalarData;

UCLASS()
class RINC_API URinCCalculateDamageMagCalc : public UGameplayModMagnitudeCalculation
{
	GENERATED_BODY()
	
public:
    URinCCalculateDamageMagCalc();

protected:
    float CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const override;

private:
    FGameplayTag GetTargetElementType(const FGameplayTagContainer& InTags) const;

    float GetDamageBaseScalar(const FGameplayEffectSpec& Spec) const;

    float GetDamageElementalScalar(const FGameplayEffectSpec& Spec, const FGameplayTagContainer& InTags) const;

protected:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    URinCElementalScalarData* ElementalScalarData;

private:
    FGameplayEffectAttributeCaptureDefinition SourceAttackDef;

    FGameplayEffectAttributeCaptureDefinition SourceCritChanceDef;

    FGameplayEffectAttributeCaptureDefinition SourceMoraleDef;

    FGameplayEffectAttributeCaptureDefinition SourceMoraleThresholdDef;

    FGameplayEffectAttributeCaptureDefinition TargetMoraleDef;

    FGameplayEffectAttributeCaptureDefinition TargetMoraleThresholdDef;

    FGameplayEffectAttributeCaptureDefinition TargetDefenseDef;

    FGameplayEffectAttributeCaptureDefinition TargetDodgeChanceDef;
};
