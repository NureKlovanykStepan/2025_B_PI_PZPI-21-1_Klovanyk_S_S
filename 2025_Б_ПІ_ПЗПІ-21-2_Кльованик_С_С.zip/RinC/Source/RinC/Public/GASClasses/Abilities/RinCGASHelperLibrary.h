// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "GASClasses/Abilities/RinCGameplayEffectContext.h"
#include "RinCGASHelperLibrary.generated.h"

UCLASS()
class RINC_API URinCGASHelperLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable)
    static void SetElementTypeTag(FGameplayEffectContextHandle ContextHandle, FGameplayTag Tag);

    UFUNCTION(BlueprintPure)
    static FGameplayTag GetElementTypeTag(FGameplayEffectContextHandle ContextHandle);

    static void SetIsCrit(FGameplayEffectContextHandle ContextHandle, bool IsCrit);

    static bool GetIsCrit(FGameplayEffectContextHandle ContextHandle);

    static void SetWasDodged(FGameplayEffectContextHandle ContextHandle, bool WasDodged);

    static bool GetWasDodged(FGameplayEffectContextHandle ContextHandle);

    /* Searches for a tag that matches the parent tag*/
    static FGameplayTag GetElementTagFromContainer(const FGameplayTagContainer& InTags, const FGameplayTag& ParentTag);

    static FGameplayTag GetElementTagFromContainer(const TArray<FName>& InTagNames, const FGameplayTag& ParentTag);
};
