// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "RinCPartyInventoryComponent.h"
#include "RinCCartridgeComponent.generated.h"

class ARinCBaseCartridge;
class ARinCBaseCharacter;

/* 
    CartridgeComponent is created for each character (Monster/Hero), 
    it is responsible for managing cartridges specifically for it's owner 
*/
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class RINC_API URinCCartridgeComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	URinCCartridgeComponent();

    void EquipCartridge(ARinCBaseCartridge* Cartridge);

    void UnequipCartridge(ARinCBaseCartridge* Cartridge);

    FORCEINLINE TArray<ARinCBaseCartridge*> GetEquippedCartridges() const { return EquippedCartridges; }

    void AddEquippedCartridge(ARinCBaseCartridge* Cartridge);

    void UnequipAllCartridges();

protected:
	virtual void BeginPlay() override;

private:
    TArray<ARinCBaseCartridge*> EquippedCartridges;
};
