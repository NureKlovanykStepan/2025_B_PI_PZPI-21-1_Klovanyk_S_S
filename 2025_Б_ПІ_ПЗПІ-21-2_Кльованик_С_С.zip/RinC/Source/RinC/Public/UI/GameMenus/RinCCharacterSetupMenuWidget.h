// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UI/GameMenus/RinCBaseGameMenuWidget.h"
#include "Cartridges/Helpers/RinCCartridgeType.h"
#include "RinCPartyInventoryComponent.h"
#include "RinCCharacterSetupMenuWidget.generated.h"

class URinCCharacterSideMenuWidget;
class URinCCartridgeDescriptionWidget;
class URinCObjectSlotWidget;
class ARinCBaseCharacter;
class ARinCBaseCartridge;
class UWrapBox;
class UTextBlock;

DECLARE_LOG_CATEGORY_EXTERN(LogURinCCharacterSetupMenuWidget, Log, All);

UCLASS()
class RINC_API URinCCharacterSetupMenuWidget : public URinCBaseGameMenuWidget
{
	GENERATED_BODY()

protected:
    virtual void NativeConstruct() override;

private:
    UFUNCTION()
    void OnEquipmentSlotClickedLMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);

    UFUNCTION()
    void OnEquipmentSlotClickedRMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);

    void UpdateInventoryWrapBox(TArray<ARinCBaseCartridge*> StoredCartridges);

    void UpdateInventoryWrapBox(FRinCStoredCartridges StoredCartridges);

    void CreateSlotsForStoredCartridges(TArray<ARinCBaseCartridge*> StoredCartridges);

    void EquipCartridge(UObject* CartridgeObject, URinCObjectSlotWidget* ClickedSlot);

    void UpdateEquippedCartridges(ARinCBaseCharacter* Character);

    URinCCartridgeData* GetCartridgeData(UObject* InCartridge) const;

    virtual void UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters) override;

    virtual void HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot) override;

    void UpdateInventoryOnCartridgeStateChange(FPrimaryAssetId CartridgeAssetId);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UWrapBox* InventoryWrapBox;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCartridgeDescriptionWidget* CartridgeDescriptionWidget;

    /* Slot widgets */
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* WeaponSlot;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* ArmorSlot;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* ArtifactSlot1;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* ArtifactSlot2;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* ArtifactSlot3;

    /*UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* SelectedCharacterNameText;*/

private:
    TArray<URinCObjectSlotWidget*> ArtifactSlots;

    TArray<URinCObjectSlotWidget*> EquipmentSlots;

    UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = true))
    TSubclassOf<URinCObjectSlotWidget> SlotWidgetClass;
};
