// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UI/GameMenus/RinCBaseGameMenuWidget.h"
#include "RinCCharacterInfoMenuWidget.generated.h"

class URinCCharacterDescriptionWidget;
class URichTextBlock;
class URinCAbilityData;
class UVerticalBox;

UCLASS()
class RINC_API URinCCharacterInfoMenuWidget : public URinCBaseGameMenuWidget
{
	GENERATED_BODY()

protected:
    virtual void NativeConstruct() override;

    virtual void HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot) override;

private:
    void UpdateGrantedAbilities(const TArray<URinCAbilityData*>& CurrentlyGrantedAbilities);

    void UpdateAbilityDescription(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UVerticalBox* AbilitiesVerticalBox;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCharacterDescriptionWidget* CharacterDescriptionWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URichTextBlock* AbilityDescriptionRichText;

    UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = true))
    TSubclassOf<URinCObjectSlotWidget> SlotWidgetClass;
};
