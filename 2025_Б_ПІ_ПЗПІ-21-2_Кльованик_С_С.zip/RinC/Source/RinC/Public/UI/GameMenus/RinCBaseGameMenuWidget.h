// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCBaseGameMenuWidget.generated.h"

class URinCObjectSlotWidget;
class URinCCharacterSideMenuWidget;
class ARinCBaseCharacter;
class ARinCBaseHeroCharacter;
class URinCPartyInventoryComponent;
class UTextBlock;

UCLASS()
class RINC_API URinCBaseGameMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable)
    void HandleVisibilityChanged(ESlateVisibility InVisibility);

protected:
    virtual void NativeConstruct() override;

    void OnCharacterSlotClickedLMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);

    virtual void HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);

    virtual void UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters);

    URinCPartyInventoryComponent* GetPartyInventoryComponent() const;

    void DeactivateSlots(const TArray<URinCObjectSlotWidget*>& SlotsToDeactivate);

    void ClearSlots(const TArray<URinCObjectSlotWidget*>& SlotsToClear);

    void UpdateSelectedCharacter();

private:
    void UpdateSelectedCharacterNameText(FPrimaryAssetId LoadedId);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCharacterSideMenuWidget* CharacterContainerWidget;

    UPROPERTY()
    ARinCBaseCharacter* SelectedCharacter;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* SelectedCharacterNameText;
};
