// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCCharacterDescriptionWidget.generated.h"

class URinCObjectSlotWidget;
class URichTextBlock;
class URinCBaseAttributeSet;

UCLASS()
class RINC_API URinCCharacterDescriptionWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
    void UpdateDescription(UObject* CharacterObject, URinCObjectSlotWidget* ClickedSlot);

private:
    void UpdateCharacterStatsText(const URinCBaseAttributeSet* CharacterAttributeSet);

    void AppendStatToString(FString& OutString, const FString& StatName, float Value, bool bIsPercentage);

    void AppendStatToString(FString& OutString, const FString& StatName, float Value);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URichTextBlock* StatsRichText;
};
