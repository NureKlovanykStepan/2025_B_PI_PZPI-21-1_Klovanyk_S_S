// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCBaseSlotWidget.generated.h"

class UImage;
class UButton;

UCLASS()
class RINC_API URinCBaseSlotWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    virtual void ClearSlot();

protected:
    void UpdateIconImage(FPrimaryAssetId AssetId, bool bShowPortrait);

    virtual void NativePreConstruct() override;

private:
    void UpdateIconImageInternal(FPrimaryAssetId LoadedId, bool bShowPortrait);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UImage* IconImage;

    UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = true))
    UMaterialInterface* PlaceholderImageMaterial;
};
