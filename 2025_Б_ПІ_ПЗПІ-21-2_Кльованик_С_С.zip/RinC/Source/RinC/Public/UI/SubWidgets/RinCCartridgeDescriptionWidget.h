// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "DataAssets/RinCCartridgeData.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "GameplayTagContainer.h"
#include "RinCCartridgeDescriptionWidget.generated.h"

class UTextBlock;
class UImage;
class ARinCBaseCartridge;
class URinCObjectSlotWidget;

USTRUCT(BlueprintType)
struct FRinCStatDisplay
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    bool bIsPercent;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FString StatDisplayName;
};

UCLASS()
class RINC_API URinCCartridgeDescriptionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    void UpdateDescription(UObject* CartridgeObject, URinCObjectSlotWidget* ClickedSlot);

protected:
    void SetupDescription(ARinCBaseCartridge* Cartridge);

private:
    void SetupDescriptionInternal(ARinCBaseCartridge* Cartridge);

    void UpdateIconImage(UMaterialInterface* Material);

    void UpdateStatsText(const TArray<FRinCAppliedCartridgeStat>& Stats);

    void AppendStatToString(FString& OutString, const FString& StatName, float Value, bool bIsPercentage);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* DisplayNameText;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* StatsText;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* DescriptionText;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UImage* IconImage;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TMap<FGameplayTag, FRinCStatDisplay> TagStatDisplayMap;
};
