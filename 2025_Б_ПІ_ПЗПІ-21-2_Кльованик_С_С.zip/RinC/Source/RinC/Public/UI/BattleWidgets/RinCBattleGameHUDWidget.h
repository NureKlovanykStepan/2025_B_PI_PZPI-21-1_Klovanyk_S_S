// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCBattleGameHUDWidget.generated.h"

class URinCHeroStatusWidget;
class UTextBlock;
class ARinCBaseCharacter;
class UHorizontalBox;
class URinCAbilityData;
class URinCObjectSlotWidget;

UCLASS()
class RINC_API URinCBattleGameHUDWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
    void NativeConstruct() override;

private:
    void BindAndUpdateHeroes();

    void UpdateHeroTurnInfo(ARinCBaseCharacter* TurnCharacter);

    void UpdateActionPoints(float NewActionPoints);

    void UpdateGrantedAbilities(const TArray<URinCAbilityData*>& CurrentlyGrantedAbilities);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCHeroStatusWidget* HeroStatus1;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCHeroStatusWidget* HeroStatus2;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCHeroStatusWidget* HeroStatus3;
	
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* ActionPointsText;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UHorizontalBox* AbilitiesHorizontalBox;

    UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = true))
    TSubclassOf<URinCObjectSlotWidget> SlotWidgetClass;

private:
    TArray<URinCHeroStatusWidget*> HeroStatuses;
};
