// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCSelectionReticleWidget.generated.h"

UCLASS()
class RINC_API URinCSelectionReticleWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    UFUNCTION(BlueprintImplementableEvent)
    void Activate();

    UFUNCTION(BlueprintImplementableEvent)
    void Deactivate();
	
};
