// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Styling/SlateTypes.h"
#include "Styling/SlateBrush.h"
#include "RinCBaseStatusWidget.generated.h"

class UProgressBar;
class ARinCBaseCharacter;

UCLASS()
class RINC_API URinCBaseStatusWidget : public UUserWidget
{
	GENERATED_BODY()

public:

    void UpdateHealth(float CurrentHealth, float MaxHealth);

    void UpdateMorale(float CurrentMorale, float MaxMorale, float MoraleThreshold);

    UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
    void SetSmoothProgressBarPercent(UProgressBar* ProgressBar, float Percent);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UProgressBar* HealthProgressBar;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UProgressBar* MoraleProgressBar;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    FLinearColor BadMoraleColor;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    FLinearColor GoodMoraleColor;
};
