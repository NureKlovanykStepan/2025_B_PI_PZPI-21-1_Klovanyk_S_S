#pragma once

UENUM(BlueprintType)
enum class ERinCCartridgeType : uint8
{
    None = 0 UMETA(Hidden),
    Artifact,
    Weapon,
    Armor
};