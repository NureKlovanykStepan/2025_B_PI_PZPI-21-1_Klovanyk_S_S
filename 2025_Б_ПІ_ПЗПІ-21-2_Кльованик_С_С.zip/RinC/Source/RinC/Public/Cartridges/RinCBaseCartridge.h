// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ActiveGameplayEffectHandle.h"
#include "GameplayAbilitySpecHandle.h"
#include "Interfaces/RinCAssetIdentifiable.h"
#include "GameplayTagContainer.h"
#include "RinCBaseCartridge.generated.h"

class UAbilitySystemComponent;
class URinCCartridgeData;

USTRUCT()
struct FRinCAppliedCartridgeStat
{
    GENERATED_BODY()

    float Magnitude;

    FGameplayTag StatTag;
};

UCLASS()
class RINC_API ARinCBaseCartridge : public AActor, public IRinCAssetIdentifiable
{
	GENERATED_BODY()
	
public:	
	ARinCBaseCartridge();

public:
    virtual void Equip(UAbilitySystemComponent* AbilitySystemComponent);

    virtual void Unequip(UAbilitySystemComponent* AbilitySystemComponent);

    virtual FPrimaryAssetId GetDataPrimaryAssetId() override;

    FORCEINLINE void SetCartridgeDataPrimaryAssetId(FPrimaryAssetId AssetId) { CartridgeDataPrimaryAssetId = AssetId; }

    /* May return nullptr if data asset wasn't loaded beforehand */
    URinCCartridgeData* GetCartridgeData();

    FORCEINLINE TArray<FRinCAppliedCartridgeStat> GetAppliedStats() const { return AppliedStats; }

    FORCEINLINE void AddAppliedStat(const FRinCAppliedCartridgeStat& Stat) { AppliedStats.Add(Stat); };

protected:
	virtual void BeginPlay() override;

private:
    FActiveGameplayEffectHandle GrantStatsToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent);

private:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Cartridge", meta = (AllowPrivateAccess = "true"))
    FPrimaryAssetId CartridgeDataPrimaryAssetId;

    /* Handle of a gameplay effect that was applied by this cartridge */
    FActiveGameplayEffectHandle ActiveGameplayEffectHandle;

    /* Handle of a gameplay ability that was granted by this cartridge */
    FGameplayAbilitySpecHandle GameplayAbilitySpecHandle;

    TArray<FRinCAppliedCartridgeStat> AppliedStats;
};
