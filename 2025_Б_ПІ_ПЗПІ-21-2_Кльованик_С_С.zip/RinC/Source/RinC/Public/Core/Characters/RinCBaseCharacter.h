// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AbilitySystemInterface.h"
#include "GameplayEffectTypes.h"
#include "Interfaces/RinCAssetIdentifiable.h"
#include "RinCBaseCharacter.generated.h"

class USpringArmComponent;
class UCameraComponent;
struct FInputActionValue;
class UAbilitySystemComponent;
class URinCBaseAttributeSet;
class URinCBaseAbilitySet;
class URinCCombatComponent;
struct FGameplayAbilitySpecHandle;
class URinCCartridgeComponent;
class URinCCharacterBattleData;
class ARinCSelectionReticleActor;
class URinCAbilityData;
class UWidgetComponent;

DECLARE_MULTICAST_DELEGATE_OneParam(FOnCharacterStatChangedSignature, float/*NewStatValue*/)
DECLARE_MULTICAST_DELEGATE_TwoParams(FOnCharacterHealthChangedSignature, float/*NewStatValue*/, float/*MaxStatValue*/)
DECLARE_MULTICAST_DELEGATE_ThreeParams(FOnCharacterMoraleChangedSignature, float/*NewStatValue*/, float/*MaxStatValue*/, float/*MoraleThreshold*/)
DECLARE_MULTICAST_DELEGATE(FOnCharacterDeathSignature)

UCLASS(Abstract)
class RINC_API ARinCBaseCharacter : public ACharacter, public IAbilitySystemInterface, public IRinCAssetIdentifiable
{
	GENERATED_BODY()

public:
    ARinCBaseCharacter();

public:
    FORCEINLINE USpringArmComponent* GetCameraBoom() const { return CameraBoom; }

    FORCEINLINE UCameraComponent* GetFollowCamera() const { return FollowCamera; }

    UFUNCTION(BlueprintPure)
    URinCCombatComponent* GetCombatComponent() const;

    UFUNCTION(BlueprintPure)
    const URinCBaseAttributeSet* GetBaseAttributeSet() const;

    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;

    UFUNCTION(BlueprintPure)
    UAnimMontage* GetBuffMontage();

    UFUNCTION(BlueprintPure)
    UAnimMontage* GetAttackMontage();

    UAnimMontage* GetDeathMontage();

    virtual FPrimaryAssetId GetDataPrimaryAssetId() override;

    FORCEINLINE URinCCartridgeComponent* GetCartridgeComponent() const { return CartridgeComponent; }

    FORCEINLINE URinCBaseAbilitySet* GetInitialAbilitySet() const { return InitialAbilitySet; }

    void SetSelectionReticleState(bool bIsActive);

    void SpawnDeathNiagara();

    TArray<URinCAbilityData*> GetAllCurrentAbilities();

protected:
    virtual void BeginPlay() override;

    virtual void HealthChanged(const FOnAttributeChangeData& Data);

    virtual void MoraleChanged(const FOnAttributeChangeData& Data);

    virtual void EnergyChanged(const FOnAttributeChangeData& Data);

    virtual void ActionPointsChanged(const FOnAttributeChangeData& Data);

    virtual void HandleDeath();

private:
    void ExecuteHitReaction();

    UAnimMontage* GetRandomMontageFromArray(TArray<UAnimMontage*> Montages);

public:
    FOnCharacterHealthChangedSignature OnHealthChanged;

    FOnCharacterMoraleChangedSignature OnMoraleChanged;

    FOnCharacterStatChangedSignature OnEnergyChanged;

    FOnCharacterStatChangedSignature OnActionPointsChanged;

    FOnCharacterDeathSignature OnCharacterDeath;

protected:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|GAS", meta = (AllowPrivateAccess = "true"))
    UAbilitySystemComponent* AbilitySystemComponent;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|GAS", meta = (AllowPrivateAccess = "true"))
    const URinCBaseAttributeSet* AttributeSet;

    UPROPERTY(EditDefaultsOnly, Category = "RinC|GAS")
    URinCBaseAbilitySet* InitialAbilitySet;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|Components", meta = (AllowPrivateAccess = "true"))
    URinCCombatComponent* CombatComponent;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|Components", meta = (AllowPrivateAccess = "true"))
    URinCCartridgeComponent* CartridgeComponent;

    UPROPERTY(Transient)
    TArray<FGameplayAbilitySpecHandle> InitiallyGrantedAbilitySpecHandles;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
    USpringArmComponent* CameraBoom;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
    UCameraComponent* FollowCamera;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Battle", meta = (AllowPrivateAccess = "true"))
    URinCCharacterBattleData* CharacterBattleData;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    UWidgetComponent* SelectionReticleWidgetComponent;

private:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = "true"))
    FPrimaryAssetId CharacterDataPrimaryAssetId;
};
