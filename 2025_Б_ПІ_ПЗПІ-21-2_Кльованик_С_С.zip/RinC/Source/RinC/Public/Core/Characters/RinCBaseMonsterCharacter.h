// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Core/Characters/RinCBaseCharacter.h"
#include "RinCBaseMonsterCharacter.generated.h"

class UWidgetComponent;

UCLASS()
class RINC_API ARinCBaseMonsterCharacter : public ARinCBaseCharacter
{
	GENERATED_BODY()
	
public:
    ARinCBaseMonsterCharacter();

protected:
    virtual void BeginPlay() override;

    virtual void HandleDeath() override;

    virtual void HealthChanged(const FOnAttributeChangeData& Data) override;

    virtual void MoraleChanged(const FOnAttributeChangeData& Data) override;

protected:
    UPROPERTY()
    FTimerHandle MonsterDeathTimerHandle;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    UWidgetComponent* StatusWidgetComponent;
};
