// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "GASClasses/Helpers/RinCAbilityInput.h"
#include "RinCBasePlayerController.generated.h"

class UInputMappingContext;
class UInputAction;
struct FInputActionValue;
class ARinCBaseHeroCharacter;
class UNiagaraSystem;
class ARinCBattleCamera;
class URinCPartyInventoryComponent;

UCLASS()
class RINC_API ARinCBasePlayerController : public APlayerController
{
	GENERATED_BODY()
	
public:
    ARinCBasePlayerController();

public:
    FORCEINLINE URinCPartyInventoryComponent* GetPartyInventoryComponent() { return PartyInventoryComponent; }
        
    void AddMappingContext(UInputMappingContext* MappingContext);

    void RemoveMappingContext(UInputMappingContext* MappingContext);

    FORCEINLINE UInputMappingContext* GetDefaultMappingContext() const { return DefaultMappingContext; };

    FORCEINLINE UInputMappingContext* GetCombatMappingContext() const { return CombatMappingContext; };

    FORCEINLINE ARinCBattleCamera* GetBattleCamera() const { return BattleCamera; }

    /* Makes battle camera look at current selected target */
    void LookAtSelectedTarget();

    void DetachBattleCamera();

    virtual void SetupInputComponent() override;

protected:
    virtual void BeginPlay() override;

    virtual void OnPossess(APawn* InPawn) override;

    void HandleCombatTargetSelection(bool bIsNextTarget);

protected:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputMappingContext* DefaultMappingContext;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputMappingContext* CombatMappingContext;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* SwitchToNextHeroAction;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* ToggleCharacterMenu;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* SelectNextTarget;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* SelectPreviousTarget;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Battle", meta = (AllowPrivateAccess = "true"))
    TSubclassOf<ARinCBattleCamera> BattleCameraClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Components", meta = (AllowPrivateAccess = "true"))
    URinCPartyInventoryComponent* PartyInventoryComponent;

private:
    UPROPERTY()
    ARinCBattleCamera* BattleCamera;
};
