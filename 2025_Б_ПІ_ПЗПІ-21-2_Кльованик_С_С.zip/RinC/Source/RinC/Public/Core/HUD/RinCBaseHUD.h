// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "GameplayTagContainer.h"
#include "Core/HUD/RinCLayerType.h"
#include "RinCBaseHUD.generated.h"

class URinCPrimaryLayoutWidget;
class ARinCFloatingTextActor;
class ARinCSelectionReticleActor;
class ARinCBattleGameHUDWidget;
class ARinCBaseCharacter;
class ARinCBaseCartridge;

UCLASS()
class RINC_API ARinCBaseHUD : public AHUD
{
	GENERATED_BODY()

public:
    void ToggleCharacterMenu();

protected:
    virtual void BeginPlay() override;

private:
    void FocusInputOnGame();

    void FocusInputOnGameAndUI();

    void PopContentFromGameLayer();

    void PushBattleGameHUDWidgetToGameLayer();

    void PushTurnPopUp(ARinCBaseCharacter* TurnCharacter);

    void PushNewCartridgePopUp();

private:
    UPROPERTY()
    URinCPrimaryLayoutWidget* PrimaryLayoutWidgetInstance;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSubclassOf<URinCPrimaryLayoutWidget> PrimaryLayoutWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftCharacterMenuClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftBattleGameHUDWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftYourTurnWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftEnemyTurnWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftNewCartridgePopUpWidgetClass;
};
