# pragma once

UENUM(BlueprintType)
enum class ERinCLayerType : uint8
{
    None = 0 UMETA(Hidden),
    GameLayer,
    GameMenuLayer,
    MenuLayer,
    ModalLayer
};