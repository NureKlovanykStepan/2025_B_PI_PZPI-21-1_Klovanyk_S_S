// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "DataAssets/RinCBaseData.h"
#include "GameplayTagContainer.h"
#include "ActiveGameplayEffectHandle.h"
#include "Cartridges/Helpers/RinCCartridgeType.h"
#include "RinCCartridgeData.generated.h"

class UGameplayAbility;
class UGameplayEffect;
class ARinCBaseCartridge;
class URinCAbilityData;
class UAbilitySystemComponent;
struct FGameplayAbilitySpecHandle;

USTRUCT(BlueprintType)
struct FRinCCartridgeStat
{
    GENERATED_BODY()

    /** Min magnitude, which will be used by GameplayEffect's mod to modify character stats */
    UPROPERTY(EditDefaultsOnly)
    float MinMagnitude;

    /** Max magnitude, which will be used by GameplayEffect's mod to modify character stats */
    UPROPERTY(EditDefaultsOnly)
    float MaxMagnitude;

    /**
     * Distribution curve asset that maps a uniform random input (X: 0-1) to
     * biased output (Y: 0-1). Lower Y values = worse stats.
     * - Linear curve = equal probability
     * - Concave curve = bias toward low values (worse stats)
     * - Convex curve = bias toward high values (good stats)
     */
    UPROPERTY(EditDefaultsOnly, Category = "Distribution")
    UCurveFloat* ProbabilityDistributionCurve;

    /** Tag which will be bound with Magnitude is used by a GameplayEffect to apply magnitude to the correct mod */
    UPROPERTY(EditDefaultsOnly)
    FGameplayTag StatTag;
};

UCLASS()
class RINC_API URinCCartridgeData : public URinCBaseData
{
	GENERATED_BODY()
	
public:
    FPrimaryAssetId GetPrimaryAssetId() const override;

    FGameplayAbilitySpecHandle GrantAbilityToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent) const;

    void InitCartridgeStats(ARinCBaseCartridge* Cartridge) const;

private:
    float GenerateRandomStatMagnitude(float MinMagnitude, float MaxMagnitude, UCurveFloat* ProbabilityDistributionCurve) const;

public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Display")
    ERinCCartridgeType CartridgeType;

    /** A gameplay ability that could be granted by this cartridge (can be left empty) */
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Ability")
    URinCAbilityData* GameplayAbilityDataToGrant;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Stats")
    TArray<FRinCCartridgeStat> CartridgeStats;

    /** GameplayEffect, which will modify character stats */
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Stats")
    TSubclassOf<UGameplayEffect> GameplayEffectClass;
};
