// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "DataAssets/RinCBaseData.h"
#include "GASClasses/Helpers/RinCAbilityInput.h"
#include "RinCAbilityData.generated.h"

class UGameplayAbility;

UCLASS()
class RINC_API URinCAbilityData : public URinCBaseData
{
	GENERATED_BODY()
	
public:
    FPrimaryAssetId GetPrimaryAssetId() const override;

public:
    UPROPERTY(EditDefaultsOnly, Category = "RinC|Ability")
    TSubclassOf<UGameplayAbility> GameplayAbility;
};
