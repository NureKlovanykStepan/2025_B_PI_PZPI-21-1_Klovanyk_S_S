// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "RinCElementalScalarData.generated.h"

USTRUCT(BlueprintType)
struct FRinCTargetElementScalar
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TMap<FGameplayTag, float> TargetElementScalarMap;
};

UCLASS()
class RINC_API URinCElementalScalarData : public UDataAsset
{
	GENERATED_BODY()
	
public:
    float GetScalarValue(const FGameplayTag& AttackElementTag, const FGameplayTag& TargetElementTag);

public:
    /** Attack element to Target element scalar table */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TMap<FGameplayTag, FRinCTargetElementScalar> GeneralElementalScalarMap;
};
