// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "RinCAssetIdentifiable.generated.h"

// This class does not need to be modified.
UINTERFACE(MinimalAPI)
class URinCAssetIdentifiable : public UInterface
{
	GENERATED_BODY()
};


class RINC_API IRinCAssetIdentifiable
{
	GENERATED_BODY()

public:
    virtual FPrimaryAssetId GetDataPrimaryAssetId();
};
